# Primus: Central SQS Orchestrator
## System Overview & Vision

### The Problem Primus Solves

**Before Primus:** Message flow was point-to-point.
- OMNI → Engine → Alpaca (no queue buffering)
- No backpressure handling → picks dropped under load
- No DLQ → failed orders lost
- No circuit breaker → cascading failures
- No audit trail → hard to debug issues

**With Primus:** Message flow is queued & supervised.
- OMNI → Primus Queue → Engine → Alpaca (buffered)
- Automatic scaling when queues back up
- DLQ captures all failures for analysis
- Circuit breaker prevents cascade
- Full audit trail in CHRONICLE

---

## Architecture (High Level)

```
┌─────────────────────────────────────────────────────────┐
│                   NEXUS TRADING SYSTEM                   │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  Cipher/Sage/Atlas (Picks)                              │
│       │                                                  │
│       ▼                                                  │
│  ┌──────────┐                                           │
│  │  OMNI    │ (Synthesis & GO/NO-GO)                   │
│  └────┬─────┘                                           │
│       │                                                  │
│       ▼ (sends structured messages)                    │
│  ┌────────────────────────────────────────────┐        │
│  │ ✨ PRIMUS SQS ORCHESTRATOR (NEW)           │        │
│  │                                             │        │
│  │ • Message routing (to correct engine)       │        │
│  │ • Deduplication & idempotency              │        │
│  │ • Load balancing (50/50 ATG vs ATM)        │        │
│  │ • Circuit breaker (auto-degradation)       │        │
│  │ • Rate limiting (per-engine throttle)      │        │
│  │ • Real-time health scoring                 │        │
│  │ • End-to-end message tracking              │        │
│  └─┬──────────────────────────────────────────┘        │
│    │                                                    │
│    ├──────────────────────────────────────┐           │
│    │                                      │            │
│    ▼ (SQS Queue per engine)               │            │
│ ATG Engines (3)      ATM Engines (2)      │            │
│ • SWING              • SWING              │            │
│ • INTRADAY           • MULTIWEEK          │            │
│ • GAMMA                                    │            │
│    │                                      │            │
│    └──────────────────────────────────────┘           │
│                    │                                   │
│            ┌───────┴──────────┐                       │
│            │                  │                        │
│            ▼                  ▼                        │
│    ┌──────────────┐    ┌──────────────┐              │
│    │  Capital     │    │ Specialized  │              │
│    │  Handler v1  │    │ Engines      │              │
│    │ • Pre-trade  │    │ • AILS       │              │
│    │ • Verify $   │    │ • AMAT       │              │
│    │ • Lock       │    │ • ATEM       │              │
│    │ • Position   │    │ • ATOM       │              │
│    │   tracking   │    │              │              │
│    └──────┬───────┘    └──────┬───────┘              │
│           │                   │                       │
│           └─────────┬─────────┘                       │
│                    │                                   │
│                    ▼                                   │
│           ┌──────────────────┐                       │
│           │ Alpaca Paper API │                       │
│           │ (Order Execution)│                       │
│           └──────────────────┘                       │
│                                                       │
│  🔍 Primus Monitoring (Real-time):                  │
│  • Queue depths (all engines)                        │
│  • Latencies (P50/P95/P99)                          │
│  • Error rates & DLQ tracking                        │
│  • Health scores (0-100 per engine)                 │
│  • Circuit breaker state                             │
│  • Capital utilization                               │
│                                                       │
└───────────────────────────────────────────────────────┘
```

---

## Core Responsibilities

### 1. Message Routing
**Function**: Take synthesis result from OMNI, route to correct engine queue.

**Logic**:
```python
if trade.type == "VERTICAL_SPREAD":
    if trade.dte < 5:
        target = "atm_swing"  # Short-dated spreads
    else:
        target = "atm_multiweek"  # Longer-dated
elif trade.symbol in GAMMA_HEAVY:
    target = "atg_gamma"
elif time_in_market < 5_min:
    target = "atg_intraday"
else:
    target = "atg_swing"
```

### 2. Deduplication
**Function**: Prevent same trade from being executed twice.

**Method**: 
- Hash trade details (symbol, strike, expiration, side, quantity)
- Check if message_id already processed in last 5 minutes
- If duplicate → return cached result (don't re-queue)

### 3. Load Balancing
**Function**: Distribute load evenly across similar engines.

**Strategy**:
- If 2 ATG engines available, split picks 50/50
- If 1 engine overloaded (queue depth > 100), route to other
- Failover: If ATG down, try to reroute to ATM (same trade type)

### 4. Circuit Breaker
**Function**: Automatically degrade gracefully when engine is failing.

**States**:
- **CLOSED** (normal): Forward all messages
- **HALF_OPEN** (testing recovery): Forward 10% of messages, monitor
- **OPEN** (broken): Drop messages, alert ops, trigger auto-recovery

**Trip conditions** (any one triggers):
- Error rate > 10% (DLQ bound)
- P99 latency > 5 seconds
- Queue processing rate drops to 0 (stuck)

**Recovery**:
- Wait 5 minutes
- If error rate < 1% → reset to CLOSED
- Else → stay OPEN, alert ops

### 5. Rate Limiting
**Function**: Respect per-engine throughput limits.

**Limits** (configurable):
- ATG_SWING: 100 msg/sec (high priority)
- ATG_INTRADAY: 50 msg/sec
- ATM_SWING: 100 msg/sec
- Global ceiling: 500 msg/sec total

**Implementation**: Token bucket algorithm (smooth bursty traffic)

### 6. Health Scoring
**Function**: Generate 0-100 health score for each engine.

**Formula**:
```
base_score = 100
- max(0, queue_depth - 100) / 10  // -1 per 10 msgs over 100
- min(20, p99_latency / 250)      // -20 max for latency
- min(30, error_rate * 3)         // -30 max for errors

health_score = max(0, min(100, base_score))
```

**Interpretation**:
- 90-100: Excellent
- 70-89: Good (monitor)
- 50-69: Degraded (consider circuit break)
- < 50: Critical (circuit open)

### 7. End-to-End Tracking
**Function**: Audit trail for every message.

**Tracking points**:
1. Message created (source, timestamp, trade details)
2. Message enqueued (Primus assigns tracking ID)
3. Message dequeued (engine starts processing)
4. Message processing starts (engine received)
5. Capital lock (pre-trade verification)
6. Order submitted (Alpaca API call)
7. Order confirmation (Alpaca response)
8. Position recorded (internal state updated)
9. Message success/failure (final status)

All logged to CHRONICLE.

---

## Monitoring & Observability

### Real-Time Metrics (collected every 30 seconds)

| Metric | Source | Alert Threshold |
|--------|--------|-----------------|
| Queue Depth | SQS GetQueueAttributes | > 1000 |
| P95 Latency | CHRONICLE | > 2000ms |
| Error Rate | DLQ depth / total messages | > 5% |
| Health Score | Calculated | < 70 |
| Circuit Breaker State | Primus state | any OPEN |
| Capital Drift | Pre-trade check | > 0.1% |

### Dashboards
- **Primus Overview**: All engines at a glance
- **Per-Engine Detail**: Queue depth, latency, error rate, health
- **DLQ Management**: Failed message count, reason breakdown
- **Historical Trends**: Performance over time

### Alerts (Telegram)
```
🟢 OK: All engines healthy
🟡 WARNING: {engine} queue > 500, investigate latency
🔴 CRITICAL: {engine} circuit breaker OPEN, auto-recovery in progress
```

---

## Integration Points

### OMNI ← → Primus
- **Input**: Synthesis result (trade details, confidence score)
- **Output**: Execution status (success, DLQ, circuit-open)
- **Latency Target**: < 100ms

### Primus ← → Engines (SQS)
- **Input**: Engine processes message from queue
- **Output**: Execution result (success, error, capital_insufficient)
- **Latency Target**: < 500ms total

### Primus ← → Capital Handler
- **Pre-trade**: Verify capital available before enqueue
- **Post-execution**: Lock/unlock capital as needed
- **Drift detection**: Alert if actual != allocated

### Primus → CHRONICLE
- **Log every message**: ID, engine, timestamp, status
- **Log metrics**: Queue depths, latencies every 30s
- **Log circuit breaker events**: Trip/recovery + reason

---

## Failure Scenarios & Recovery

### Scenario 1: Single Engine Fails (Zombie Process)
- **Detection**: Health check timeout (30s)
- **Action**: Circuit breaker OPEN
- **Recovery**: Auto-restart via launchd + re-queue messages
- **Time to recover**: < 2 minutes

### Scenario 2: Queue Backlog (> 5000 messages)
- **Detection**: Real-time monitoring
- **Action**: Add worker threads automatically
- **Prevention**: Primus throttles new picks from OMNI (signal: backoff)
- **Time to clear**: Depends on root cause

### Scenario 3: Alpaca API Rate Limit (429)
- **Detection**: Message in DLQ with reason=api_error
- **Action**: Exponential backoff + circuit breaker triggers
- **Recovery**: Auto-replay after 60s cooldown
- **Time**: 60-120 seconds

### Scenario 4: Capital Insufficient
- **Detection**: Pre-trade verification fails
- **Action**: Message DLQ'd, capital remains unlocked
- **Recovery**: Manual (ops must free capital or reduce position size)
- **Alert**: Critical → page ops team

---

## Implementation Roadmap

### Phase 1: MVP (Week 1)
- [ ] Create SQS queues (9 engines + DLQ)
- [ ] Implement basic message router
- [ ] Implement health monitor
- [ ] Log to CHRONICLE

### Phase 2: Reliability (Week 2)
- [ ] Circuit breaker logic
- [ ] Rate limiter
- [ ] DLQ analysis & replay
- [ ] Alert system

### Phase 3: Observability (Week 3)
- [ ] Dashboards (Grafana)
- [ ] Historical metrics
- [ ] Anomaly detection
- [ ] Runbook automation

### Phase 4: Optimization (Week 4)
- [ ] Load balancing tuning
- [ ] Latency optimization
- [ ] Scaling automation
- [ ] Disaster recovery drills

---

## Success Criteria

By end of Primus v1.0 launch:

- ✅ **99.5% message delivery** (only legitimate DLQ)
- ✅ **< 500ms P95 latency** (message to Alpaca)
- ✅ **< 2% error rate** (DLQ bound)
- ✅ **< 2 min recovery** from single engine failure
- ✅ **Zero capital drift** (verified at every step)
- ✅ **Full audit trail** (every message tracked)

---

## Questions for Ahmed

1. Should Primus throttle new picks from OMNI if queue backs up?
   - Or just alert OMNI and let it decide?

2. What's the acceptable "safe loss" percentage?
   - (i.e., if < 1% of messages fail, is that OK?)

3. Should Primus have authority to trigger circuit breaker?
   - Or only suggest to ops?

4. How aggressively should we scale workers?
   - Immediately when queue > 100, or more conservatively?

---

Generated: 2026-06-02  
For: Maximus Implementation  
Status: Specification Ready
