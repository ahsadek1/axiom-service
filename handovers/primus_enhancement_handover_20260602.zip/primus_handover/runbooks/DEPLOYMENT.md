# Primus v1.0 Deployment Runbook

**Target:** Production deployment of Primus SQS orchestrator  
**Duration:** ~1 day  
**Rollback:** Simple (no stateful changes in Alpaca)  

---

## Pre-Deployment Checklist

### Infrastructure
- [ ] AWS SQS access verified (IAM role has permissions)
- [ ] All 9 engine queues accessible
- [ ] CHRONICLE database writable
- [ ] Network connectivity to all dependencies verified

### Code & Tests
- [ ] All unit tests passing (`code/tests/test_*.py`)
- [ ] Integration tests passing
- [ ] Code review completed by Cipher
- [ ] No secrets in code (checked)

### Configuration
- [ ] Queue URLs populated in `config/primus_config.yaml`
- [ ] Alert routing configured (Telegram chat IDs set)
- [ ] Thresholds reviewed and approved (warning/critical levels)
- [ ] Circuit breaker parameters tuned

### Team
- [ ] Maximus (impl) ready to deploy
- [ ] Cipher (reviewer) ready to validate
- [ ] Axiom (oversight) ready to monitor
- [ ] On-call engineer assigned for first 24h

---

## Phase 1: Database Setup (30 minutes)

### 1.1 Create Primus Tables

```bash
# On the CHRONICLE database server
sqlite3 /Users/ahmedsadek/nexus/data/chronicle.db < schemas/primus_monitoring_schema.sql

# Verify tables created
sqlite3 /Users/ahmedsadek/nexus/data/chronicle.db "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'primus%';"

# Expected output: 12 tables
# primus_queue_config
# primus_health_snapshots
# primus_engine_metrics
# primus_circuit_breaker
# primus_anomalies
# primus_rate_limit
# primus_message_tracking
# primus_daily_health_score
# primus_dlq_messages
# primus_alerts
# primus_config_changes
# primus_service_health
```

### 1.2 Verify Initial Data

```bash
# Check queue configurations loaded
sqlite3 /Users/ahmedsadek/nexus/data/chronicle.db "SELECT engine_name, queue_name FROM primus_queue_config ORDER BY engine_name;"

# Expected: 9 engines listed
```

### 1.3 Create Backup

```bash
# Backup CHRONICLE before Primus goes live
cp /Users/ahmedsadek/nexus/data/chronicle.db \
   /Users/ahmedsadek/nexus/data/chronicle.backup.$(date +%Y%m%d_%H%M%S).db
```

---

## Phase 2: Deploy Primus Service (45 minutes)

### 2.1 Prepare Service Directory

```bash
# Create Primus service directory
mkdir -p /Users/ahmedsadek/nexus/primus-service
cd /Users/ahmedsadek/nexus/primus-service

# Copy code from handover
cp /tmp/primus_handover/code/*.py .
mkdir tests
cp /tmp/primus_handover/code/tests/*.py tests/

# Copy configuration
mkdir config
cp /tmp/primus_handover/config/*.yaml config/
```

### 2.2 Install Dependencies

```bash
# Create Python virtual environment
python3 -m venv venv
source venv/bin/activate

# Install requirements
pip install -r requirements.txt

# Typical requirements:
# boto3>=1.28.0        # AWS SQS client
# fastapi>=0.100.0     # API server
# uvicorn>=0.23.0      # ASGI server
# aiohttp>=3.8.0       # Async HTTP
# pydantic>=2.0.0      # Data validation
# python-dotenv>=1.0.0 # Config from .env
```

### 2.3 Configure Environment

```bash
# Copy .env template
cp /tmp/primus_handover/config/.env.primus .env

# Edit .env with actual values
# AWS_REGION=us-east-1
# AWS_ACCESS_KEY_ID=xxxxx
# AWS_SECRET_ACCESS_KEY=xxxxx
# CHRONICLE_DB_PATH=/Users/ahmedsadek/nexus/data/chronicle.db
# PRIMUS_LOG_LEVEL=INFO
# PRIMUS_PORT=8008
```

### 2.4 Run Tests

```bash
# Unit tests
python -m pytest tests/test_sqs_monitor.py -v

# Integration tests (if SQS accessible)
python -m pytest tests/test_integration.py -v

# Load test (check dashboard performance under load)
python -m pytest tests/test_load.py -v
```

### 2.5 Start Primus Service

```bash
# Option A: Systemd service (recommended for production)
# Copy service definition
sudo cp deployment/primus.service /etc/systemd/system/

# Enable & start
sudo systemctl daemon-reload
sudo systemctl enable primus
sudo systemctl start primus
sudo systemctl status primus

# Option B: Manual start (for testing/debugging)
cd /Users/ahmedsadek/nexus/primus-service
source venv/bin/activate
python -m primus_service
```

### 2.6 Verify Service Started

```bash
# Check service is running
curl http://localhost:8008/health

# Expected response:
# {
#   "status": "healthy",
#   "uptime_sec": 15,
#   "engines_monitored": 9,
#   "last_snapshot_age_sec": 3
# }

# Check logs
tail -f ~/.openclaw/logs/primus.log
```

---

## Phase 3: Integration Testing (45 minutes)

### 3.1 Verify Queue Monitoring

```bash
# Check that Primus is collecting metrics
curl http://localhost:8008/metrics/latest

# Expected: Current depth for all 9 engines
{
  "timestamp": "2026-06-02T15:30:00Z",
  "engines": {
    "ATG-Swing": {"depth": 42, "status": "healthy", "latency_p95_ms": 35},
    "ATG-Intraday": {"depth": 156, "status": "warning", "latency_p95_ms": 68},
    ...
  },
  "overall_health": 7.8
}
```

### 3.2 Verify Message Tracking

```bash
# Inject a test pick and verify tracking
python scripts/inject_test_pick.py \
  --symbol NVDA \
  --direction long \
  --capital 5000

# Query tracking
curl "http://localhost:8008/tracking/CIPHER_TEST_001"

# Expected: Track through stages
{
  "pick_id": "CIPHER_TEST_001",
  "current_stage": "executing",
  "synthesis_completed_at": "2026-06-02T15:31:00Z",
  "engine_task_started_at": "2026-06-02T15:31:15Z",
  "status": "in_progress"
}
```

### 3.3 Verify Circuit Breaker

```bash
# Simulate engine failure
python scripts/simulate_engine_failure.py --engine ATG-Swing --failures 10

# Check circuit breaker state
curl http://localhost:8008/circuit-breaker/ATG-Swing

# Expected: OPEN state
{
  "engine": "ATG-Swing",
  "state": "OPEN",
  "failure_count": 10,
  "last_state_change": "2026-06-02T15:32:00Z",
  "recovery_timeout_sec": 60
}

# Manually recover
curl -X POST http://localhost:8008/circuit-breaker/ATG-Swing/reset

# Verify back to HALF_OPEN
```

### 3.4 Verify Dashboard

```bash
# Open dashboard in browser
open http://localhost:8008/dashboard

# Verify:
# ✓ All 9 engines visible
# ✓ Real-time depth updates (should see changes every 10s)
# ✓ Health scores displayed
# ✓ Anomalies section shows any alerts
# ✓ Rate limit feedback visible
```

### 3.5 Verify Alerts

```bash
# Send test alert
curl -X POST http://localhost:8008/test-alert \
  -H "Content-Type: application/json" \
  -d '{"severity": "warning", "message": "Test alert"}'

# Check Telegram received message
# (should arrive in NEXUS_ALPHA group)
```

---

## Phase 4: Stress Testing (30 minutes)

### 4.1 Load Test Monitoring

```bash
# Simulate 2x normal message rate
python scripts/load_test.py \
  --rate_multiplier 2 \
  --duration_sec 300

# Monitor:
# ✓ Dashboard responds <100ms
# ✓ Metrics collected every 10s without gaps
# ✓ No database lock contention
# ✓ CPU/memory within expected ranges
```

### 4.2 Check Database Performance

```bash
# Query performance under load
time sqlite3 /Users/ahmedsadek/nexus/data/chronicle.db \
  "SELECT COUNT(*) FROM primus_engine_metrics WHERE engine_name='ATG-Swing';"

# Expected: <100ms response time
```

### 4.3 Verify No Message Loss

```bash
# Stop Primus
sudo systemctl stop primus

# Inject 1000 test messages into one queue
python scripts/inject_test_messages.py --count 1000 --queue atg-swing-queue

# Restart Primus
sudo systemctl start primus

# Verify all messages tracked
sleep 120  # Let Primus catch up

curl http://localhost:8008/metrics/latest | \
  jq '.engines."ATG-Swing".messages_tracked'

# Expected: 1000
```

---

## Phase 5: Production Handoff (30 minutes)

### 5.1 Cut Over OMNI Integration

```bash
# Currently OMNI routes picks directly to engines
# Change OMNI to route through Primus rate limiter

# In OMNI config, update:
ENGINE_QUEUE_RATE_LIMIT_ENDPOINT = "http://localhost:8008/rate-limit"

# OMNI now checks rate limit before submitting picks
# Expected latency added: <50ms per 60-sec check
```

### 5.2 Update Cipher Tracking

```bash
# Enable pick tracking in Cipher
# Cipher starts injecting pick_id when creating picks

# Verify in Primus:
curl http://localhost:8008/tracking?status=in_progress | head -10

# Should see active picks being tracked
```

### 5.3 Enable Alerting

```bash
# Configure alert routing
# Edit config/alert_routes.yaml

# Example:
# alerts:
#   CRITICAL:
#     - telegram: NEXUS_HEALTH
#     - telegram: AHMED_DM
#     - pagerduty: oncall_sre
#   HIGH:
#     - telegram: NEXUS_HEALTH
#   MEDIUM:
#     - slack: #nexus-alerts

# Restart Primus
sudo systemctl restart primus
```

### 5.4 Create Runbooks

```bash
# Operators should have these ready:
# ✓ QUEUE_DIAGNOSTICS.md - how to debug queue issues
# ✓ DLQ_RECOVERY.md - how to recover from DLQ
# ✓ DISASTER_RECOVERY.md - full system recovery
# ✓ MANUAL_INTERVENTIONS.md - when to manually intervene

# Post them in shared location accessible during market hours
cp /tmp/primus_handover/runbooks/* /Users/ahmedsadek/nexus/docs/runbooks/
```

### 5.5 Verify 24/7 Operation

```bash
# Final checks before go-live:
✓ Service starts automatically on server reboot
✓ Logs are being collected and archived
✓ Backups are running daily
✓ Alerts are routed to on-call engineer
✓ Dashboard is accessible from operations laptop
✓ All 9 engines are being monitored
✓ Circuit breaker is active (any failures trigger CB)
✓ Rate limiting is active (OMNI respects feedback)
✓ Message tracking is working (Pick → Order correlation)
```

---

## Phase 6: First 24 Hours Monitoring

### 6.1 Continuous Monitoring

```bash
# Set up continuous dashboard monitoring
# (Maximus should watch for first 2 hours after market open)

# Key metrics to watch:
# 1. All 9 engines showing in metrics
# 2. Queue depths stable (no growing queues)
# 3. Error rates <1% per engine
# 4. No anomalies detected
# 5. Alert notifications arriving on time

# Command to check every 5 min:
watch -n 300 'curl -s http://localhost:8008/metrics/latest | jq .overall_health'
```

### 6.2 Log Monitoring

```bash
# Watch for errors/warnings in logs
tail -f ~/.openclaw/logs/primus.log | grep -E "ERROR|CRITICAL|ANOMALY"

# Expected: Minimal errors, just normal operational logs
```

### 6.3 Database Growth

```bash
# Check that database isn't growing uncontrollably
# (should grow ~1-5 MB per day based on 9,000+ msg/day)

du -h /Users/ahmedsadek/nexus/data/chronicle.db

# If exceeding expectations, may need to archive older data
```

### 6.4 Escalation Path

If issues detected:

1. **Non-critical (warning):** Log, monitor, continue
2. **Critical (engine disabled):** Alert Maximus + Cipher
3. **Emergency (Primus crash):** Restart service, alert Ahmed
4. **Unrecoverable:** Disable Primus, route picks directly to engines (fallback)

---

## Rollback Procedure (Emergency Only)

If Primus becomes unstable:

```bash
# 1. Stop Primus
sudo systemctl stop primus

# 2. Restore OMNI to direct routing (no rate limit check)
# Edit OMNI config, set:
USE_PRIMUS_RATE_LIMITER = false

# Restart OMNI
sudo systemctl restart omni

# 3. Restore database backup (if needed)
# Only if CHRONICLE was corrupted
cp /Users/ahmedsadek/nexus/data/chronicle.backup.20260602_150000.db \
   /Users/ahmedsadek/nexus/data/chronicle.db

# 4. Verify engines still working
# Check that picks are still executing through direct routing

# 5. Root cause analysis
# Review Primus logs to understand what went wrong
```

---

## Post-Deployment Validation

### Checklist (Day 2, 9 AM ET)

- [ ] Primus has been running 24+ hours without restart
- [ ] All 9 engines show healthy metrics
- [ ] No unresolved alerts in dashboard
- [ ] Database size is reasonable (<100 MB)
- [ ] Message tracking correlation is >99.9%
- [ ] Circuit breakers have not triggered
- [ ] Rate limiting is stable (OMNI getting consistent feedback)
- [ ] Dashboard loads in <100ms
- [ ] All runbooks have been reviewed by operations team

### Sign-Off

Once all items checked, Primus v1.0 is **Production Ready**.

```
Deployed by: Maximus
Deployed at: 2026-06-02 16:00 ET
Reviewed by: Cipher
Approved by: Ahmed Sadek
Status: ✅ LIVE
```

---

## Future Maintenance

- **Weekly:** Review health scores for trend anomalies
- **Monthly:** Archive old tracking data (>30 days) to cold storage
- **Quarterly:** Review and tune thresholds based on real usage patterns
- **As-needed:** Add new engines to queue config and circuit breaker

---

**Document Version:** 1.0  
**Created:** 2026-06-02  
**Maintainer:** Maximus
