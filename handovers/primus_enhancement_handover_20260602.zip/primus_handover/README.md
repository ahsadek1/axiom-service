# Primus Enhancement Handover Package
**For Maximus — SQS Oversight & Orchestration**

Generated: 2026-06-02  
Status: Production-Ready Specification

## Package Contents

### 📋 Documentation
- **PRIMUS_OVERVIEW.md** — High-level system design
- **ARCHITECTURE.md** — Detailed SQS message flow & topology
- **INTEGRATION_POINTS.md** — How Primus connects to OMNI, engines, capital handler

### 🔧 Architecture
- **SQS_CONFIGURATION.md** — Queue setup, message formats, rate limits
- **QUEUE_TOPOLOGY.md** — All 9 engines + DLQ + control queues
- **MESSAGE_SPECIFICATION.json** — Trade execution & health check message schemas

### 💻 Code Templates
- **primus_sqs_monitor.py** — Real-time queue monitoring (465 lines)
- **primus_orchestrator.py** — Message routing & circuit breaker logic
- **sqs_health_checks.py** — Per-engine health scoring
- **circuit_breaker.py** — Automated degradation & recovery
- **message_tracker.py** — End-to-end message audit trail

### ⚙️ Configurations
- **engine_config.json** — Rate limits, timeouts, thresholds per engine
- **circuit_breaker_config.json** — Trip thresholds & recovery strategy
- **alert_config.json** — Alert routing by severity
- **scaling_config.json** — Auto-worker-spawn thresholds

### 📖 Runbooks
- **DLQ_RECOVERY.md** — How to diagnose & replay failed messages
- **CIRCUIT_BREAKER_RESET.md** — Manual recovery procedures
- **SCALING_PLAYBOOK.md** — When & how to add capacity
- **DISASTER_RECOVERY.md** — Emergency procedures

### 🗄️ Database Schemas
- **primus_tables.sql** — All required tables (metrics, DLQ, circuit state, audit)
- **indices.sql** — Performance indices
- **views.sql** — Useful queries for monitoring

---

## Quick Start for Maximus

### Phase 1: Foundation (Week 1)
1. Review ARCHITECTURE.md + SQS_CONFIGURATION.md
2. Create SQS queues using queue topology specs
3. Implement primus_sqs_monitor.py (monitoring foundation)

### Phase 2: Core Logic (Week 2)
1. Implement primus_orchestrator.py (message routing)
2. Implement circuit_breaker.py (automated degradation)
3. Implement message_tracker.py (audit trail)

### Phase 3: Integration (Week 3)
1. Connect to OMNI (receive synthesis results)
2. Connect to engines (route messages, collect responses)
3. Connect to CHRONICLE (log all metrics & events)
4. Connect to capital handler (pre-trade verification)

### Phase 4: Operations (Week 4)
1. Build dashboards (Grafana/Prometheus)
2. Test runbooks (DLQ recovery, circuit breaker reset)
3. Load test (validate 500 msg/sec throughput)
4. Failover drills (engine outage simulation)

---

## Key Success Metrics

By end of implementation, Primus should achieve:

- ✅ **99.5% message delivery** to engines
- ✅ **< 500ms P95 latency** end-to-end
- ✅ **< 2% error rate** (DLQ bound)
- ✅ **Automatic recovery** in < 2 minutes
- ✅ **Zero capital drift** (verified pre-trade)
- ✅ **Full audit trail** in CHRONICLE

---

## Dependencies

- AWS SQS (production queues)
- AWS CloudWatch (monitoring)
- CHRONICLE database (audit)
- Capital Handler v1.0 (pre-trade verification)
- All 9 SQS subengines (consumers)
- OMNI synthesis (message producer)

---

## Handover Notes from Axiom

The preflight validation system has been deployed and is running at 8:30 AM ET daily.
Primus will extend that to **real-time** monitoring & **automated remediation**.

Key insight: The 9 engines are rock-solid when data flows correctly. Primus's job is to
ensure data flows at the right speed, in the right order, with automatic recovery from
transient failures.

Focus on:
1. **Circuit breaker precision** — Don't over-react to single failures
2. **DLQ diagnosis** — Root-cause analysis before replay
3. **Capital lock semantics** — Never let capital drift during execution
4. **Alerting philosophy** — Signal-to-noise ratio (avoid alert fatigue)

Questions for Ahmed/OMNI: Should Primus have authority to throttle new picks from
OMNI if queues back up? Or just alert and let OMNI decide?

---

Good luck, Maximus. This is the connective tissue of the entire trading system. 🚀

— Axiom
