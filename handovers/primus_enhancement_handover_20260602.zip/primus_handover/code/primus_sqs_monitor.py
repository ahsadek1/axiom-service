"""
primus_sqs_monitor.py — Real-Time SQS Queue Monitoring
========================================================

Monitors all 9 engine queues in real-time:
- Queue depth (number of messages waiting)
- Latency (time in queue)
- Error rates
- Anomalies (spikes, stalls, etc.)

Usage:
    monitor = PrimusSQSMonitor()
    asyncio.run(monitor.start())

Dependencies:
    - boto3 (AWS SQS client)
    - asyncio (async/await)
    - CHRONICLE database (for logging)
"""

import asyncio
import json
import logging
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Dict, List, Optional, Tuple
import sqlite3

import boto3

logger = logging.getLogger(__name__)

# =====================================================================
# Configuration
# =====================================================================

ENGINES = {
    "ATG-Swing": "atg-swing-queue",
    "ATG-Intraday": "atg-intraday-queue",
    "AILS": "ails-queue",
    "ATM-MultiWeek": "atm-multiweek-queue",
    "ATM-0DTE": "atm-0dte-queue",
    "AMAT-Prime": "amat-prime-queue",
    "Engine-7": "engine-7-queue",
    "Engine-8": "engine-8-queue",
    "Engine-9": "engine-9-queue",
}

MONITORING_INTERVAL = 10  # seconds
ANOMALY_CHECK_INTERVAL = 60  # seconds
HISTORY_RETENTION = 3600  # keep last hour of history


# =====================================================================
# Data Classes
# =====================================================================

class QueueStatus(Enum):
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class QueueMetrics:
    """Current metrics for a single queue."""
    engine: str
    queue_url: str
    timestamp: str
    
    # Current state
    depth: int  # Number of messages
    depth_bytes: int  # Approx total bytes
    
    # Latency (P50, P95, P99 in ms)
    latency_p50: float = 0.0
    latency_p95: float = 0.0
    latency_p99: float = 0.0
    
    # Throughput
    messages_processed_1h: int = 0
    errors_1h: int = 0
    
    # Calculated
    error_rate: float = 0.0  # % errors
    status: QueueStatus = QueueStatus.HEALTHY
    oldest_message_age_sec: float = 0.0
    
    # Thresholds
    warning_depth: int = 200
    critical_depth: int = 500


@dataclass
class AnomalyEvent:
    """Detected anomaly event."""
    timestamp: str
    engine: str
    anomaly_type: str  # "spike", "stall", "high_error_rate"
    severity: str  # "warning", "critical"
    current_value: float
    baseline_value: float
    message: str


@dataclass
class HealthSnapshot:
    """Complete health snapshot of all queues at one moment."""
    timestamp: str
    queue_metrics: List[QueueMetrics] = field(default_factory=list)
    anomalies: List[AnomalyEvent] = field(default_factory=list)
    overall_status: QueueStatus = QueueStatus.HEALTHY
    system_health_score: float = 10.0


# =====================================================================
# Queue Metrics Collector
# =====================================================================

class QueueMetricsCollector:
    """Collects metrics from SQS queues."""
    
    def __init__(self):
        self.sqs = boto3.client("sqs", region_name="us-east-1")
        self.history: Dict[str, List[QueueMetrics]] = {
            engine: [] for engine in ENGINES.keys()
        }
    
    async def collect_metrics(self, engine: str, queue_url: str) -> QueueMetrics:
        """Collect metrics for a single queue."""
        try:
            # Get queue attributes
            response = self.sqs.get_queue_attributes(
                QueueUrl=queue_url,
                AttributeNames=[
                    "ApproximateNumberOfMessages",
                    "ApproximateNumberOfMessagesNotVisible",
                    "ApproximateNumberOfMessagesDelayed",
                    "CreatedTimestamp",
                    "LastModifiedTimestamp",
                    "VisibilityTimeout",
                    "MessageRetentionPeriod",
                ],
            )
            
            attrs = response["Attributes"]
            depth = int(attrs.get("ApproximateNumberOfMessages", 0))
            in_flight = int(attrs.get("ApproximateNumberOfMessagesNotVisible", 0))
            
            # Determine status
            warning_threshold = 200 if "0DTE" not in engine else 500
            critical_threshold = 500 if "0DTE" not in engine else 2000
            
            if depth >= critical_threshold:
                status = QueueStatus.CRITICAL
            elif depth >= warning_threshold:
                status = QueueStatus.WARNING
            else:
                status = QueueStatus.HEALTHY
            
            metrics = QueueMetrics(
                engine=engine,
                queue_url=queue_url,
                timestamp=datetime.now(timezone.utc).isoformat(),
                depth=depth,
                depth_bytes=depth * 1024,  # Rough estimate
                status=status,
                warning_depth=warning_threshold,
                critical_depth=critical_threshold,
            )
            
            # Store in history
            self.history[engine].append(metrics)
            if len(self.history[engine]) > HISTORY_RETENTION:
                self.history[engine].pop(0)
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error collecting metrics for {engine}: {e}")
            return QueueMetrics(
                engine=engine,
                queue_url=queue_url,
                timestamp=datetime.now(timezone.utc).isoformat(),
                depth=-1,
                depth_bytes=0,
                status=QueueStatus.CRITICAL,
            )
    
    async def collect_all(self) -> List[QueueMetrics]:
        """Collect metrics for all queues."""
        tasks = [
            self.collect_metrics(engine, queue_url)
            for engine, queue_url in ENGINES.items()
        ]
        return await asyncio.gather(*tasks)


# =====================================================================
# Anomaly Detector
# =====================================================================

class AnomalyDetector:
    """Detects anomalies in queue metrics."""
    
    SPIKE_THRESHOLD = 2.0  # 2x baseline = spike
    ERROR_SPIKE_THRESHOLD = 5.0  # 5x baseline = error spike
    STALL_AGE_THRESHOLD = 30  # seconds
    
    def __init__(self):
        self.baselines: Dict[str, float] = {}
        self.error_baselines: Dict[str, float] = {}
    
    def detect(self, metrics_list: List[QueueMetrics]) -> List[AnomalyEvent]:
        """Detect anomalies in current metrics."""
        anomalies = []
        
        for metrics in metrics_list:
            engine = metrics.engine
            
            # Update baselines
            if engine not in self.baselines:
                self.baselines[engine] = float(metrics.depth)
                self.error_baselines[engine] = 0.0
            
            # Detect queue spike
            if metrics.depth > self.SPIKE_THRESHOLD * self.baselines[engine]:
                anomalies.append(AnomalyEvent(
                    timestamp=metrics.timestamp,
                    engine=engine,
                    anomaly_type="spike",
                    severity="warning",
                    current_value=metrics.depth,
                    baseline_value=self.baselines[engine],
                    message=f"Queue depth spiked from {self.baselines[engine]:.0f} → {metrics.depth}",
                ))
                self.baselines[engine] = metrics.depth
            
            # Detect message stall (old message in queue)
            if metrics.oldest_message_age_sec > self.STALL_AGE_THRESHOLD:
                anomalies.append(AnomalyEvent(
                    timestamp=metrics.timestamp,
                    engine=engine,
                    anomaly_type="stall",
                    severity="critical",
                    current_value=metrics.oldest_message_age_sec,
                    baseline_value=10.0,
                    message=f"Message stuck in queue for {metrics.oldest_message_age_sec:.1f}s",
                ))
            
            # Detect error rate spike
            if metrics.error_rate > self.ERROR_SPIKE_THRESHOLD * self.error_baselines[engine]:
                anomalies.append(AnomalyEvent(
                    timestamp=metrics.timestamp,
                    engine=engine,
                    anomaly_type="high_error_rate",
                    severity="critical",
                    current_value=metrics.error_rate,
                    baseline_value=self.error_baselines[engine],
                    message=f"Error rate spiked from {self.error_baselines[engine]:.1f}% → {metrics.error_rate:.1f}%",
                ))
                self.error_baselines[engine] = metrics.error_rate
        
        return anomalies


# =====================================================================
# Health Snapshot Builder
# =====================================================================

class HealthSnapshotBuilder:
    """Builds complete health snapshots."""
    
    def __init__(self, anomaly_detector: AnomalyDetector):
        self.detector = anomaly_detector
    
    def build(self, metrics_list: List[QueueMetrics]) -> HealthSnapshot:
        """Build complete health snapshot."""
        
        # Detect anomalies
        anomalies = self.detector.detect(metrics_list)
        
        # Calculate overall status
        critical_count = sum(1 for m in metrics_list if m.status == QueueStatus.CRITICAL)
        warning_count = sum(1 for m in metrics_list if m.status == QueueStatus.WARNING)
        
        if critical_count > 0:
            overall_status = QueueStatus.CRITICAL
        elif warning_count > 2:  # More than 2 engines warning
            overall_status = QueueStatus.WARNING
        else:
            overall_status = QueueStatus.HEALTHY
        
        # Calculate health score (0-10)
        # Score formula: Start at 10, subtract for each issue
        score = 10.0
        for metrics in metrics_list:
            if metrics.status == QueueStatus.CRITICAL:
                score -= 2.0
            elif metrics.status == QueueStatus.WARNING:
                score -= 0.5
            
            # Subtract for high error rates
            score -= metrics.error_rate * 0.1
        
        score = max(0.0, min(10.0, score))
        
        return HealthSnapshot(
            timestamp=datetime.now(timezone.utc).isoformat(),
            queue_metrics=metrics_list,
            anomalies=anomalies,
            overall_status=overall_status,
            system_health_score=score,
        )


# =====================================================================
# CHRONICLE Logger
# =====================================================================

class CHRONICLELogger:
    """Logs metrics to CHRONICLE database."""
    
    def __init__(self, db_path: str = "/Users/ahmedsadek/nexus/data/chronicle.db"):
        self.db_path = db_path
    
    def log_snapshot(self, snapshot: HealthSnapshot) -> bool:
        """Log health snapshot to CHRONICLE."""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create table if not exists
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS primus_health_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    overall_status TEXT NOT NULL,
                    health_score REAL NOT NULL,
                    snapshot_json TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Insert snapshot
            cursor.execute("""
                INSERT INTO primus_health_snapshots 
                (timestamp, overall_status, health_score, snapshot_json)
                VALUES (?, ?, ?, ?)
            """, (
                snapshot.timestamp,
                snapshot.overall_status.value,
                snapshot.system_health_score,
                json.dumps(asdict(snapshot), default=str),
            ))
            
            conn.commit()
            conn.close()
            return True
            
        except Exception as e:
            logger.error(f"Error logging to CHRONICLE: {e}")
            return False


# =====================================================================
# Main Monitor
# =====================================================================

class PrimusSQSMonitor:
    """Main SQS monitoring service."""
    
    def __init__(self):
        self.collector = QueueMetricsCollector()
        self.detector = AnomalyDetector()
        self.builder = HealthSnapshotBuilder(self.detector)
        self.chronicle = CHRONICLELogger()
        self.latest_snapshot: Optional[HealthSnapshot] = None
        self.running = False
    
    async def monitor_loop(self):
        """Main monitoring loop."""
        logger.info("Starting Primus SQS Monitor")
        self.running = True
        
        while self.running:
            try:
                # Collect metrics from all queues
                metrics_list = await self.collector.collect_all()
                
                # Build snapshot
                snapshot = self.builder.build(metrics_list)
                self.latest_snapshot = snapshot
                
                # Log to CHRONICLE
                self.chronicle.log_snapshot(snapshot)
                
                # Log anomalies
                for anomaly in snapshot.anomalies:
                    logger.warning(f"ANOMALY: {anomaly.engine} - {anomaly.message}")
                
                # Log summary
                logger.info(
                    f"Health: {snapshot.system_health_score:.1f}/10 | "
                    f"Status: {snapshot.overall_status.value} | "
                    f"Anomalies: {len(snapshot.anomalies)}"
                )
                
                await asyncio.sleep(MONITORING_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(MONITORING_INTERVAL)
    
    def get_latest_snapshot(self) -> Optional[HealthSnapshot]:
        """Get latest health snapshot."""
        return self.latest_snapshot
    
    def get_engine_metrics(self, engine: str) -> Optional[QueueMetrics]:
        """Get latest metrics for specific engine."""
        if not self.latest_snapshot:
            return None
        for m in self.latest_snapshot.queue_metrics:
            if m.engine == engine:
                return m
        return None
    
    async def start(self):
        """Start the monitor."""
        await self.monitor_loop()
    
    def stop(self):
        """Stop the monitor."""
        self.running = False


# =====================================================================
# Entry Point
# =====================================================================

async def main():
    """Run the monitor."""
    monitor = PrimusSQSMonitor()
    await monitor.start()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())
