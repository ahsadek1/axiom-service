-- Primus SQS Monitoring Schema
-- Creates all tables needed for Primus v1.0 operation

-- =====================================================================
-- 1. Queue Configuration & State
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_queue_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    engine_name TEXT NOT NULL UNIQUE,
    queue_name TEXT NOT NULL,
    queue_url TEXT NOT NULL,
    region TEXT NOT NULL DEFAULT 'us-east-1',
    dlq_name TEXT,
    dlq_url TEXT,
    
    -- Thresholds (configurable)
    warning_depth INTEGER DEFAULT 200,
    critical_depth INTEGER DEFAULT 500,
    target_latency_p95_ms INTEGER DEFAULT 100,
    
    -- Capacity
    max_messages_per_min INTEGER DEFAULT 1000,
    optimal_queue_depth_min INTEGER DEFAULT 20,
    optimal_queue_depth_max INTEGER DEFAULT 100,
    
    -- Circuit breaker
    cb_failure_threshold INTEGER DEFAULT 10,  -- Disable after N failures
    cb_failure_window_sec INTEGER DEFAULT 600,  -- in this time window
    cb_recovery_timeout_sec INTEGER DEFAULT 60,
    
    -- Status
    is_active INTEGER DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_engine_name ON primus_queue_config(engine_name);


-- =====================================================================
-- 2. Health Snapshots (periodic recording of all engines)
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_health_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_timestamp TEXT NOT NULL,  -- When snapshot was taken
    
    -- Overall status
    overall_status TEXT NOT NULL,  -- 'healthy', 'warning', 'critical'
    health_score REAL NOT NULL,  -- 0.0-10.0
    
    -- Counts
    engines_healthy INTEGER DEFAULT 0,
    engines_warning INTEGER DEFAULT 0,
    engines_critical INTEGER DEFAULT 0,
    
    -- Anomalies detected
    anomaly_count INTEGER DEFAULT 0,
    
    -- Full snapshot JSON (for archive)
    snapshot_json TEXT,
    
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(snapshot_timestamp)
);

CREATE INDEX idx_snapshot_timestamp ON primus_health_snapshots(snapshot_timestamp DESC);
CREATE INDEX idx_health_score ON primus_health_snapshots(health_score);


-- =====================================================================
-- 3. Per-Engine Metrics (recorded every 10 seconds)
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_engine_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    engine_name TEXT NOT NULL,
    metric_timestamp TEXT NOT NULL,
    
    -- Queue state
    queue_depth INTEGER NOT NULL,  -- Number of messages
    queue_depth_bytes INTEGER DEFAULT 0,  -- Approx bytes
    messages_in_flight INTEGER DEFAULT 0,  -- Being processed
    
    -- Latency (milliseconds)
    latency_p50 REAL DEFAULT 0.0,
    latency_p95 REAL DEFAULT 0.0,
    latency_p99 REAL DEFAULT 0.0,
    
    -- Throughput (last hour)
    messages_processed_1h INTEGER DEFAULT 0,
    errors_1h INTEGER DEFAULT 0,
    
    -- Calculated metrics
    error_rate REAL DEFAULT 0.0,  -- % (0-100)
    oldest_message_age_sec REAL DEFAULT 0.0,
    queue_full_percent INTEGER DEFAULT 0,  -- 0-100
    
    -- Status
    status TEXT NOT NULL,  -- 'healthy', 'warning', 'critical'
    
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (engine_name) REFERENCES primus_queue_config(engine_name)
);

CREATE INDEX idx_engine_metric ON primus_engine_metrics(engine_name, metric_timestamp DESC);
CREATE INDEX idx_metric_timestamp ON primus_engine_metrics(metric_timestamp DESC);


-- =====================================================================
-- 4. Circuit Breaker State
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_circuit_breaker (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    engine_name TEXT NOT NULL UNIQUE,
    
    -- State: CLOSED (healthy), OPEN (disabled), HALF_OPEN (recovery test)
    current_state TEXT NOT NULL DEFAULT 'CLOSED',
    
    -- Failure tracking
    failure_count INTEGER DEFAULT 0,  -- Failures in current window
    last_failure_timestamp TEXT,
    failure_window_start TEXT,
    
    -- State transitions
    last_state_change TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    state_changed_by TEXT,  -- 'auto' or operator name
    
    -- Recovery
    half_open_test_message_id TEXT,
    half_open_started_at TEXT,
    
    -- Manual override
    manual_override_state TEXT,  -- 'OPEN', 'CLOSED', or NULL
    manual_override_reason TEXT,
    manual_override_by TEXT,
    manual_override_until TEXT,
    
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (engine_name) REFERENCES primus_queue_config(engine_name)
);

CREATE INDEX idx_cb_state ON primus_circuit_breaker(current_state);


-- =====================================================================
-- 5. Anomaly Detection Events
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_anomalies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    anomaly_timestamp TEXT NOT NULL,
    engine_name TEXT NOT NULL,
    
    -- Anomaly type
    anomaly_type TEXT NOT NULL,  -- 'spike', 'stall', 'error_rate_jump', etc.
    severity TEXT NOT NULL,  -- 'warning', 'critical'
    
    -- Values
    current_value REAL NOT NULL,
    baseline_value REAL NOT NULL,
    deviation_ratio REAL,  -- current/baseline
    
    -- Details
    message TEXT NOT NULL,
    
    -- Response
    alert_sent INTEGER DEFAULT 0,
    alert_sent_at TEXT,
    response_taken TEXT,  -- Description of action taken
    response_taken_at TEXT,
    
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (engine_name) REFERENCES primus_queue_config(engine_name)
);

CREATE INDEX idx_anomaly_engine ON primus_anomalies(engine_name, anomaly_timestamp DESC);
CREATE INDEX idx_anomaly_severity ON primus_anomalies(severity, anomaly_timestamp DESC);


-- =====================================================================
-- 6. Rate Limiting State
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_rate_limit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    
    -- Current rate limit
    current_rate_limit_per_min INTEGER NOT NULL,  -- picks/min we tell OMNI
    changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    changed_by TEXT,
    reason TEXT,
    
    -- OMNI feedback
    omni_requested_rate INTEGER,
    omni_last_update TEXT,
    
    -- Calculated capacity
    total_capacity_per_min INTEGER,
    bottleneck_engine TEXT,
    
    -- History (JSON for archive)
    last_10_decisions TEXT,  -- JSON array of decisions
    
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);


-- =====================================================================
-- 7. Message Tracking (end-to-end)
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_message_tracking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    
    -- Message IDs at each stage
    pick_id TEXT NOT NULL,
    synthesis_request_id TEXT,
    engine_task_id TEXT,
    execution_order_id TEXT,
    position_id TEXT,
    
    -- Timeline
    pick_created_at TEXT NOT NULL,
    synthesis_started_at TEXT,
    synthesis_completed_at TEXT,
    engine_task_queued_at TEXT,
    engine_task_started_at TEXT,
    engine_task_completed_at TEXT,
    order_created_at TEXT,
    order_filled_at TEXT,
    position_created_at TEXT,
    
    -- Status
    current_stage TEXT NOT NULL,  -- 'pick', 'synthesis', 'queued', 'executing', 'filled', 'closed'
    status TEXT NOT NULL,  -- 'in_progress', 'completed', 'failed'
    
    -- Failure tracking
    failure_stage TEXT,
    failure_reason TEXT,
    failure_timestamp TEXT,
    
    -- Performance
    total_latency_ms INTEGER,  -- pick_created → position_created
    
    -- Details
    symbol TEXT,
    direction TEXT,  -- 'long' or 'short'
    engine_name TEXT,
    
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (engine_name) REFERENCES primus_queue_config(engine_name)
);

CREATE INDEX idx_tracking_pick_id ON primus_message_tracking(pick_id);
CREATE INDEX idx_tracking_status ON primus_message_tracking(status, current_stage);
CREATE INDEX idx_tracking_timestamp ON primus_message_tracking(created_at DESC);


-- =====================================================================
-- 8. Daily Health Scores
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_daily_health_score (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    score_date TEXT NOT NULL,  -- YYYY-MM-DD
    engine_name TEXT NOT NULL,
    
    -- Score components (0-10)
    latency_score REAL NOT NULL,
    availability_score REAL NOT NULL,
    queue_efficiency_score REAL NOT NULL,
    capital_util_score REAL NOT NULL,
    message_age_score REAL NOT NULL,
    
    -- Overall
    daily_score REAL NOT NULL,  -- Average of above
    
    -- Thresholds for grading
    p95_latency_ms REAL,
    error_rate_pct REAL,
    avg_queue_depth INTEGER,
    capital_deployed_pct REAL,
    max_message_age_sec REAL,
    
    -- Grade
    grade TEXT,  -- 'Excellent', 'Good', 'Fair', 'Poor', 'Critical'
    
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(score_date, engine_name),
    FOREIGN KEY (engine_name) REFERENCES primus_queue_config(engine_name)
);

CREATE INDEX idx_daily_score_date ON primus_daily_health_score(score_date DESC);
CREATE INDEX idx_daily_score_engine ON primus_daily_health_score(engine_name, score_date DESC);


-- =====================================================================
-- 9. Dead-Letter Queue Tracking
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_dlq_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    engine_name TEXT NOT NULL,
    
    -- Message details
    message_id TEXT NOT NULL,
    message_body TEXT NOT NULL,
    message_attributes TEXT,  -- JSON
    
    -- Failure info
    failure_reason TEXT,
    failure_count INTEGER DEFAULT 1,  -- How many times did it fail?
    first_failure_at TEXT NOT NULL,
    last_failure_at TEXT NOT NULL,
    
    -- Recovery
    recovery_attempted INTEGER DEFAULT 0,
    recovery_attempted_at TEXT,
    recovery_success INTEGER DEFAULT 0,
    recovery_timestamp TEXT,
    
    -- Status
    status TEXT NOT NULL DEFAULT 'pending',  -- 'pending', 'recovered', 'archived'
    
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (engine_name) REFERENCES primus_queue_config(engine_name)
);

CREATE INDEX idx_dlq_engine ON primus_dlq_messages(engine_name, status);
CREATE INDEX idx_dlq_pending ON primus_dlq_messages(status, created_at DESC);


-- =====================================================================
-- 10. Alerts & Escalations
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_timestamp TEXT NOT NULL,
    
    -- Alert details
    alert_type TEXT NOT NULL,  -- 'queue_spike', 'engine_disabled', 'error_rate_jump'
    severity TEXT NOT NULL,  -- 'warning', 'critical', 'emergency'
    engine_name TEXT,
    
    -- Message
    title TEXT NOT NULL,
    details TEXT,
    
    -- Delivery
    sent_to_telegram INTEGER DEFAULT 0,
    telegram_chat_ids TEXT,  -- JSON array
    sent_to_operations INTEGER DEFAULT 0,
    sent_at TEXT,
    
    -- Acknowledgment
    acknowledged_by TEXT,
    acknowledged_at TEXT,
    ack_message TEXT,
    
    -- Status
    status TEXT NOT NULL DEFAULT 'unacknowledged',  -- 'unacknowledged', 'acknowledged', 'resolved'
    
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (engine_name) REFERENCES primus_queue_config(engine_name)
);

CREATE INDEX idx_alert_severity ON primus_alerts(severity, alert_timestamp DESC);
CREATE INDEX idx_alert_status ON primus_alerts(status, alert_timestamp DESC);


-- =====================================================================
-- 11. Configuration Audit Trail
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_config_changes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    change_timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- What changed
    config_item TEXT NOT NULL,  -- 'queue_warning_depth', 'cb_failure_threshold', etc.
    engine_name TEXT,
    
    old_value TEXT,
    new_value TEXT,
    
    -- Who changed it
    changed_by TEXT NOT NULL,
    reason TEXT,
    
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_config_change_timestamp ON primus_config_changes(change_timestamp DESC);


-- =====================================================================
-- 12. Primus Service Health
-- =====================================================================

CREATE TABLE IF NOT EXISTS primus_service_health (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    health_timestamp TEXT NOT NULL,
    
    -- Primus itself
    primus_status TEXT NOT NULL,  -- 'healthy', 'degraded', 'unhealthy'
    primus_uptime_sec INTEGER,
    
    -- Dependencies
    sqs_reachable INTEGER,
    sqs_latency_ms REAL,
    chronicle_reachable INTEGER,
    chronicle_latency_ms REAL,
    
    -- Monitoring
    snapshots_collected INTEGER DEFAULT 0,
    last_snapshot_age_sec INTEGER,
    
    -- Error tracking
    errors_last_hour INTEGER DEFAULT 0,
    
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_service_health_timestamp ON primus_service_health(health_timestamp DESC);


-- =====================================================================
-- Initialization: Populate default queue configurations
-- =====================================================================

INSERT OR IGNORE INTO primus_queue_config 
(engine_name, queue_name, queue_url, dlq_name, dlq_url, warning_depth, critical_depth, max_messages_per_min)
VALUES
('ATG-Swing', 'atg-swing-queue', 'https://sqs.us-east-1.amazonaws.com/{account}/atg-swing-queue', 'atg-swing-dlq', 'https://sqs.us-east-1.amazonaws.com/{account}/atg-swing-dlq', 200, 500, 1000),
('ATG-Intraday', 'atg-intraday-queue', 'https://sqs.us-east-1.amazonaws.com/{account}/atg-intraday-queue', 'atg-intraday-dlq', 'https://sqs.us-east-1.amazonaws.com/{account}/atg-intraday-dlq', 300, 1000, 2000),
('AILS', 'ails-queue', 'https://sqs.us-east-1.amazonaws.com/{account}/ails-queue', 'ails-dlq', 'https://sqs.us-east-1.amazonaws.com/{account}/ails-dlq', 200, 500, 500),
('ATM-MultiWeek', 'atm-multiweek-queue', 'https://sqs.us-east-1.amazonaws.com/{account}/atm-multiweek-queue', 'atm-multiweek-dlq', 'https://sqs.us-east-1.amazonaws.com/{account}/atm-multiweek-dlq', 150, 300, 300),
('ATM-0DTE', 'atm-0dte-queue', 'https://sqs.us-east-1.amazonaws.com/{account}/atm-0dte-queue', 'atm-0dte-dlq', 'https://sqs.us-east-1.amazonaws.com/{account}/atm-0dte-dlq', 500, 2000, 3000),
('AMAT-Prime', 'amat-prime-queue', 'https://sqs.us-east-1.amazonaws.com/{account}/amat-prime-queue', 'amat-prime-dlq', 'https://sqs.us-east-1.amazonaws.com/{account}/amat-prime-dlq', 400, 1500, 1500),
('Engine-7', 'engine-7-queue', 'https://sqs.us-east-1.amazonaws.com/{account}/engine-7-queue', 'engine-7-dlq', 'https://sqs.us-east-1.amazonaws.com/{account}/engine-7-dlq', 200, 500, 1000),
('Engine-8', 'engine-8-queue', 'https://sqs.us-east-1.amazonaws.com/{account}/engine-8-queue', 'engine-8-dlq', 'https://sqs.us-east-1.amazonaws.com/{account}/engine-8-dlq', 200, 500, 1000),
('Engine-9', 'engine-9-queue', 'https://sqs.us-east-1.amazonaws.com/{account}/engine-9-queue', 'engine-9-dlq', 'https://sqs.us-east-1.amazonaws.com/{account}/engine-9-dlq', 200, 500, 1000);
