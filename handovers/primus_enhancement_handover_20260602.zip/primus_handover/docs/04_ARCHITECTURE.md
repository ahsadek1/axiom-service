# Primus Architecture & System Design

**Scope:** Complete system design including message flow, component interactions, and operational guarantees  
**Audience:** Implementation team (Maximus), Architects (Cipher), Operations  

---

## System Context

### Components in Scope
```
Cipher (Pick Generation)
    ↓
Nexus Alpha (Broker Coordination)  ← NOT in scope (uses Primus as library)
    ↓
OMNI (Synthesis)
    ↓
[PRIMUS ORCHESTRATOR] ← THIS IS PRIMUS
    ↓
Engines (9 subengines)
    ↓
Alpaca (Execution)
```

### Primus Responsibility Boundary

**Primus IS:**
- SQS queue manager (monitor depth, latency, errors)
- Message router (map pick → synthesis → engine → order)
- Circuit breaker (auto-disable failing engines)
- Health scorer (1–10 daily score per engine)
- Rate limiter (backpressure to OMNI)
- Anomaly detector (queue spikes, stalls, error jumps)

**Primus IS NOT:**
- Trading decision maker
- Pick generator (Cipher does this)
- Synthesis orchestrator (OMNI does this)
- Order executor (Alpaca does this)
- Capital manager (OMNI/Capital Router do this)

---

## Message Flow Architecture

### Stage 1: Pick Generation (Cipher → pick-queue)

```
Cipher generates trade pick:
{
  id: "CIPHER_20260602_001",
  symbol: "NVDA",
  direction: "long",
  capital_required: 10000,
  confidence: 0.87,
  urgency: "medium"
}
↓
Injected into: SQS pick-queue
Timestamp: T+0
Role of Primus: LISTEN (informational only)
```

### Stage 2: Synthesis Request (pick-queue → synthesis-requests)

```
OMNI pulls pick and creates synthesis request:
{
  id: "SYNTH_20260602_001",
  pick_id: "CIPHER_20260602_001",
  symbol: "NVDA",
  engines_capable: ["ATM-0DTE", "ATG-Intraday"],
  capital_available: 10000,
  expiry_preference: "0DTE"
}
↓
Injected into: SQS synthesis-requests queue
Timestamp: T+50ms (typical)
Role of Primus: LISTEN + TRACK
  - Record synthesis start time
  - Begin tracking message ID
```

### Stage 3: Engine Task Queuing (synthesis-requests → engine queues)

```
Primus receives synthesis request and ROUTES to best engine:
  - Evaluates all capable engines
  - Checks circuit breaker state (skip disabled ones)
  - Checks capacity (don't overload queue)
  - Routes to least-loaded capable engine

Creates engine task:
{
  id: "ENGINE_ATM0DTE_001",
  synth_id: "SYNTH_001",
  engine: "ATM-0DTE",
  symbol: "NVDA",
  direction: "long",
  contracts: [...],
  capital_reserved: 10000
}
↓
Injected into: SQS atm-0dte-queue
Timestamp: T+50ms + routing latency (5–10ms)
Role of Primus: ROUTE + TRACK
  - Decide which engine gets this
  - Record routing decision
  - Update circuit breaker state for selected engine
  - Update queue depth estimates
```

### Stage 4: Engine Processing (engine-queue → engine processor)

```
Engine pulls task from queue:
  - Processes: "Create synthetic 0DTE call position"
  - Executes: Buy 10 contracts of NVDA 0DTE call @1.50
  - Creates execution order
↓
Engine task status: PROCESSING
Timestamp: T+100ms (typical, could be much longer if queue backed up)
Role of Primus: MONITOR
  - Track time in queue (latency)
  - Watch for messages stuck >30s
  - Update health metrics
```

### Stage 5: Order Execution (engine → Alpaca API)

```
Engine creates order in Alpaca:
{
  id: "ALPACA_20260602_001",
  symbol: "NVDA260607C00120000",
  qty: 10,
  side: "buy",
  limit_price: 1.50,
  time_in_force: "day"
}
↓
Alpaca processes order
Timestamp: T+150ms (typical)
Role of Primus: CORRELATE
  - Link execution order ID to engine task ID
  - Track order status callbacks from Alpaca
```

### Stage 6: Fill & Position Creation (Alpaca → position tracking)

```
Order fills at Alpaca:
{
  filled_qty: 10,
  filled_price: 1.49,
  timestamp: T+200ms
}
↓
CHRONICLE records position:
{
  position_id: "POS_001",
  order_id: "ALPACA_001",
  symbol: "NVDA260607C00120000",
  qty: 10,
  entry_price: 1.49,
  status: "open",
  pnl: 0.0
}
Timestamp: T+200ms
Role of Primus: FINALIZE
  - Complete tracking chain
  - Record total latency: T → T+200ms
  - Update health metrics with success
```

### Full Timeline Example

```
T+0ms    Cipher creates pick CIPHER_001
T+50ms   OMNI creates synthesis SYNTH_001
T+60ms   Primus routes to ATM-0DTE → ENGINE_ATM0DTE_001
T+100ms  ATM-0DTE engine pulls task from queue
T+120ms  Engine calls Alpaca with order ALPACA_001
T+150ms  Alpaca acknowledges order received
T+180ms  Order fills at 1.49
T+200ms  CHRONICLE records POS_001

TOTAL LATENCY: 200ms (pick creation → position recorded)
In queue time: 60–100ms
Processing time: 100–120ms
Execution time: 50–80ms
```

---

## Queue Topology

### SQS Queue Structure

```
┌─────────────────────────────────────────────────────────┐
│ INBOUND QUEUES                                          │
├─────────────────────────────────────────────────────────┤
│ pick-queue (Cipher → OMNI)                              │
│   - Messages: Trade picks                               │
│   - Rate: 1–10 picks/min peak                          │
│   - Retention: 4 days                                  │
│   - DLQ: pick-dlq                                      │
│                                                         │
│ synthesis-requests (OMNI → Engines via Primus)         │
│   - Messages: Synthesis requests                        │
│   - Rate: 5–20 syntheses/min peak                      │
│   - Retention: 4 days                                  │
│   - DLQ: synthesis-dlq                                 │
└─────────────────────────────────────────────────────────┘
                          ↓
           [PRIMUS ORCHESTRATOR]
           (message routing, rate limiting,
            circuit breaker, anomaly detection)
                          ↓
┌─────────────────────────────────────────────────────────┐
│ ENGINE QUEUES (9 total, one per engine)                 │
├─────────────────────────────────────────────────────────┤
│ atg-swing-queue              ← DLQ: atg-swing-dlq      │
│ atg-intraday-queue           ← DLQ: atg-intraday-dlq   │
│ ails-queue                   ← DLQ: ails-dlq            │
│ atm-multiweek-queue          ← DLQ: atm-multiweek-dlq  │
│ atm-0dte-queue               ← DLQ: atm-0dte-dlq       │
│ amat-prime-queue             ← DLQ: amat-prime-dlq     │
│ engine-7-queue               ← DLQ: engine-7-dlq       │
│ engine-8-queue               ← DLQ: engine-8-dlq       │
│ engine-9-queue               ← DLQ: engine-9-dlq       │
└─────────────────────────────────────────────────────────┘
                          ↓
           (Engine processors)
                          ↓
           Alpaca Orders (REST API)
```

### Primus Control Queues (optional, for future scaling)

```
primus-health-responses      Health check ACKs
primus-circuit-breaker-events CB state changes
primus-rate-limit-updates    Feedback to OMNI
```

---

## Component Architecture

### Core Components

```
┌────────────────────────────────────────────────────────┐
│ PRIMUS SERVICE                                         │
├────────────────────────────────────────────────────────┤
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │ API Layer (FastAPI)                              │  │
│  │ - /health                                        │  │
│  │ - /metrics/latest                               │  │
│  │ - /tracking/{message_id}                        │  │
│  │ - /circuit-breaker/{engine}                     │  │
│  │ - /rate-limit                                   │  │
│  │ - /dashboard (HTML)                             │  │
│  └──────────────────────────────────────────────────┘  │
│           ↓                                             │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Orchestration Layer                              │  │
│  │ ┌────────────────────────────────────────────┐   │  │
│  │ │ Message Router                             │   │  │
│  │ │ - Pick → Engine assignment                │   │  │
│  │ │ - Circuit breaker check                   │   │  │
│  │ │ - Capacity validation                     │   │  │
│  │ └────────────────────────────────────────────┘   │  │
│  │ ┌────────────────────────────────────────────┐   │  │
│  │ │ Rate Limiter                               │   │  │
│  │ │ - Calculate available capacity per min    │   │  │
│  │ │ - Feedback to OMNI                        │   │  │
│  │ │ - Backpressure signals                    │   │  │
│  │ └────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────┘  │
│           ↓                                             │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Monitoring Layer                                 │  │
│  │ ┌────────────────────────────────────────────┐   │  │
│  │ │ Queue Monitor (every 10s)                  │   │  │
│  │ │ - Poll all 9 engine queues for depth      │   │  │
│  │ │ - Collect latency metrics                 │   │  │
│  │ │ - Record error rates                      │   │  │
│  │ └────────────────────────────────────────────┘   │  │
│  │ ┌────────────────────────────────────────────┐   │  │
│  │ │ Health Scorer (daily)                      │   │  │
│  │ │ - Latency score (P95 vs target)           │   │  │
│  │ │ - Availability score (error rate)         │   │  │
│  │ │ - Efficiency score (queue depth)          │   │  │
│  │ │ - Capital score (utilization %)           │   │  │
│  │ │ - Message age score                       │   │  │
│  │ └────────────────────────────────────────────┘   │  │
│  │ ┌────────────────────────────────────────────┐   │  │
│  │ │ Anomaly Detector                           │   │  │
│  │ │ - Queue spike detection                   │   │  │
│  │ │ - Message stall detection                 │   │  │
│  │ │ - Error rate jump detection               │   │  │
│  │ │ - Correlated failures detection           │   │  │
│  │ └────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────┘  │
│           ↓                                             │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Storage Layer                                    │  │
│  │ - CHRONICLE: Metrics, tracking, health scores    │  │
│  │ - In-Memory: Recent metrics cache               │  │
│  │ - SQS: DLQ monitoring                           │  │
│  └──────────────────────────────────────────────────┘  │
│           ↓                                             │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Alert Layer                                      │  │
│  │ - Telegram notifications                        │  │
│  │ - Slack (optional)                             │  │
│  │ - PagerDuty (optional)                         │  │
│  └──────────────────────────────────────────────────┘  │
│                                                        │
└────────────────────────────────────────────────────────┘
```

---

## Circuit Breaker Pattern

### State Machine

```
                    CLOSED (Healthy)
                         ↑ ↓
                    (no failures
                     in 60s window)
                         ↓
                   ┌───────────┐
                   │  Failures │
                   │  > threshold
                   └───────────┘
                         ↓
        ┌─────────────────────────────────┐
        │                                 │
        │    OPEN (Disabled/Failing)      │
        │  - Stop sending messages        │
        │  - Wait 60s for recovery        │
        │  - Alert operator               │
        │                                 │
        └────────────────────────────────┘
                    (after 60s)
                         ↓
        ┌─────────────────────────────────┐
        │                                 │
        │  HALF_OPEN (Recovery Test)      │
        │  - Send 1 test message          │
        │  - Wait for response            │
        │                                 │
        └────────────────────────────────┘
              ↓ (success)    ↓ (failure)
            CLOSED          OPEN
```

### Configuration

```yaml
circuit_breaker:
  failure_threshold: 10          # Disable after 10 failures
  failure_window_sec: 600        # ...in 10 minutes
  recovery_timeout_sec: 60       # Wait 60s before recovery test
  half_open_timeout_sec: 10      # Wait 10s for test response
```

---

## Data Flow: Real-Time Monitoring

### Every 10 Seconds

```
PrimusSQSMonitor.collect_metrics()
    ↓
    For each of 9 engines:
      - GetQueueAttributes(queue_url)
      - Record: depth, latency P50/P95/P99, errors
      - Store in memory cache
    ↓
    Build HealthSnapshot
      - Aggregate across engines
      - Detect anomalies
      - Calculate health score
    ↓
    Store to CHRONICLE
      - primus_engine_metrics table (9 rows)
      - primus_health_snapshots table (1 row)
      - primus_anomalies table (N rows if anomalies)
    ↓
    Update in-memory cache
      - Latest snapshot accessible via API
      - Dashboard reads from cache (not DB) for <100ms response
```

### Rate Limiting Feedback (Every 60 Seconds)

```
RateLimitCalculator.calculate()
    ↓
    For each engine:
      - Calculate current capacity: max_rate * (100 - queue_pct) / 100
      - Apply safety margin (20% headroom)
      - Sum across all engines
    ↓
    Total available capacity = sum of individual capacities
    ↓
    Primus → OMNI via HTTP API or SQS
      "Your rate limit is now X picks/min"
    ↓
    If capacity drops >20% in 10 min:
      Send urgent backpressure signal
      "Reduce to Y picks/min ASAP"
    ↓
    OMNI adjusts synthesis rate accordingly
```

---

## Message Tracking Flow

### Correlation Chain

```
Pick ID: CIPHER_001
    ↓ (created by Cipher)
    
Synthesis ID: SYNTH_001 (when OMNI synthesizes CIPHER_001)
    ↓ (created by OMNI)
    
Engine Task ID: ENGINE_ATM0DTE_001 (when Primus routes to ATM-0DTE)
    ↓ (created by Primus)
    
Execution Order ID: ALPACA_001 (when engine submits order)
    ↓ (created by engine)
    
Position ID: POS_001 (when Alpaca fill confirms)
    ↓ (created by CHRONICLE)
    
Entry in primus_message_tracking:
{
  pick_id: "CIPHER_001",
  synthesis_request_id: "SYNTH_001",
  engine_task_id: "ENGINE_ATM0DTE_001",
  execution_order_id: "ALPACA_001",
  position_id: "POS_001",
  
  current_stage: "filled",
  status: "completed",
  total_latency_ms: 200,
  
  timestamps: {
    pick_created: T+0ms,
    synthesis_completed: T+50ms,
    engine_task_queued: T+60ms,
    engine_task_started: T+100ms,
    order_created: T+120ms,
    order_filled: T+180ms,
    position_created: T+200ms
  }
}
```

---

## Failure Modes & Recovery

### Failure 1: Engine Crashes

```
Detection:
  - Message in queue >30s (stalled)
  - OR error rate spikes to >5%
  - Circuit breaker triggers (10 failures in 10 min)

Recovery:
  - Circuit breaker: CLOSED → OPEN
  - Primus stops sending to this engine
  - Alert: "ATM-0DTE disabled due to repeated failures"
  - Operator investigates engine logs
  - Once fixed, operator manually opens CB → HALF_OPEN
  - Primus sends test message
  - If succeeds: CB → CLOSED, resume normal operation
```

### Failure 2: Queue Depth Growing (Backed Up)

```
Detection:
  - Queue depth >70% of warning threshold
  - Depth trend is increasing

Response:
  - Calculate new capacity: lower available picks/min
  - Signal OMNI to reduce synthesis rate
  - Monitor for recovery over next 5 min

If not recovering:
  - Escalate to WARNING status
  - Alert operator: "ATG-Intraday queue backed up, investigate"
  - Possible causes: slow processing, high error rate, large messages
```

### Failure 3: Message Stuck in Queue

```
Detection:
  - Message age in queue >30 seconds
  - Engine hasn't pulled it

Response:
  - Anomaly alert: "Message stuck in ails-queue for 45s"
  - Operator checks engine logs
  - If engine crashed: Restart it, message will eventually timeout/move to DLQ
  - If engine slow: Increase capacity, monitor
```

### Failure 4: DLQ Accumulation

```
Detection:
  - Primus monitors all DLQs every 60s
  - DLQ depth increasing steadily

Response:
  - Alert: "AMAT-Prime DLQ has 50 messages, investigate"
  - Operator reviews failed messages:
    - Transient errors (network) → safe to replay
    - Capital check failed → manual review before replay
    - Data validation error → fix root cause, then replay
  - Use runbook: QUEUE_DIAGNOSTICS.md → DLQ Recovery section
```

---

## Scaling Considerations

### Horizontal Scaling

If adding more engines in future:
1. Add queue to `primus_queue_config` table
2. Primus automatically monitors it (no code change needed)
3. Circuit breaker initialized to CLOSED state
4. Health scoring starts day 1

### Vertical Scaling

If message rate increases:
1. Monitor database write latency (INSERT to primus_engine_metrics)
2. If latency rising, add database indexing or partition tables by date
3. Archive old data (>30 days) to cold storage

### Load Testing

Primus itself adds <50ms per message tracked:
- 10s monitoring polling: <100ms per cycle
- Message tracking: <5ms per message INSERT
- Health score calculation: <1s per day (daily batch)

Primus can handle 10,000+ messages/sec without bottlenecking.

---

## Deployment Architecture

### Single Instance (v1.0 recommended)

```
EC2 Instance or Container
  ├─ Primus Service (port 8008)
  │  └─ Listens on http://localhost:8008
  ├─ Writes to CHRONICLE (SQLite local or network)
  ├─ Connects to AWS SQS (all regions)
  └─ Publishes to Telegram alerts
```

### High Availability (future)

```
Load Balancer
  ├─ Primus Instance 1 (active, routes messages)
  ├─ Primus Instance 2 (standby, read-only monitoring)
  └─ Primus Instance 3 (standby, read-only monitoring)

Shared CHRONICLE Database (RDS)
  └─ Handles writes from active instance
  └─ Handles reads from all instances
```

---

## API Contracts

### Input: Rate Limit Request from OMNI

```http
GET /rate-limit?requested_rate=300

Response:
{
  "approved_rate": 280,
  "reason": "ATG-Intraday queue at 85% capacity",
  "ttl_seconds": 60,
  "backpressure": false
}
```

### Input: Health Check from Operator

```http
GET /health

Response:
{
  "status": "healthy",
  "uptime_sec": 86400,
  "engines_monitored": 9,
  "health_score": 8.2,
  "last_snapshot_age_sec": 3
}
```

### Output: Alert to Telegram

```json
{
  "text": "🔴 CRITICAL: AMAT-Prime disabled (10 errors in 10min)",
  "severity": "critical",
  "engine": "AMAT-Prime",
  "chat_id": "NEXUS_HEALTH"
}
```

---

## Operational Guarantees

### Availability
- Primus aims for 99.9% uptime (36s downtime/day acceptable)
- If Primus crashes, engines continue operating independently
- Fallback: Direct routing without rate limiting (degraded mode)

### Consistency
- Message tracking accurate >99.9% of time
- Duplicates impossible (SQS ensures once-delivery)
- No message loss (backed by AWS SQS durability)

### Latency
- Dashboard API <100ms P95 (read from cache)
- Metrics collection <10s per cycle (background)
- Rate limit feedback <50ms per request

### Safety
- Circuit breaker prevents cascade failures
- Anomaly detection catches problems in seconds
- All changes audit-logged to CHRONICLE
- Manual override capability for emergency situations

---

**Document Version:** 1.0  
**Created:** 2026-06-02  
**Status:** Design Review Ready
