# Primus Vision: Role, Capabilities, Objectives

**Status:** Design Phase  
**Target Deployment:** Week of June 16, 2026  
**Implementation Lead:** Maximus  

---

## What is Primus?

**Primus** is a central **SQS orchestrator and supervisor** for the Nexus trading system. It sits at the message routing layer and provides:

1. **Visibility** — Real-time monitoring of all 9 engine queues
2. **Control** — Rate limiting, circuit breaking, automated recovery
3. **Intelligence** — Health scoring, anomaly detection, end-to-end tracking
4. **Coordination** — Syncing OMNI synthesis rate with engine capacity

---

## Core Responsibilities

### 1. Message Routing & Tracking
**Objective:** Know where every message is and why

**What it does:**
- Assigns unique tracking ID to every message at each stage
- Logs source → destination for every hop
- Records timestamps for latency calculation
- Correlates message IDs: Pick → Synthesis → Engine → Order → Position

**Example:**
```
Pick CIPHER_001 → Synthesis SYNTH_001 → Engine ENGINE_001 → 
Order ALPACA_001 → Position POS_NVDA_001

If any stage fails, Primus can pinpoint where the break happened.
```

**Data Storage:**
- CHRONICLE table: `sqs_message_tracking`
  - Fields: message_id, message_type, source_queue, dest_queue, 
    timestamp_sent, timestamp_received, status, error_reason
  - Index: message_id, timestamp

### 2. Queue Depth Monitoring
**Objective:** Never be surprised by queue growth

**What it does:**
- Polls all 9 engine queues every 10 seconds
- Records queue depth (number of messages waiting)
- Calculates depth trend (increasing? decreasing? stable?)
- Triggers alerts if depth exceeds threshold

**Thresholds (configurable):**
```yaml
atg-swing-queue:
  warning_depth: 200      # Alert at 200 msgs
  critical_depth: 500     # Emergency at 500 msgs
  target_depth: 50–100    # Healthy range

atm-0dte-queue:
  warning_depth: 500      # Higher for high-volume engine
  critical_depth: 2000
  target_depth: 100–300
```

**Dashboard shows:**
- Current depth (number)
- Trend arrow (↑ rising, ↓ falling, → stable)
- Time-to-empty estimate (if no new messages)
- Recommended action ("capacity OK" vs "reduce rate")

### 3. Latency Tracking
**Objective:** Understand delay at each processing stage

**What it does:**
- Records timestamp when message enters queue
- Records timestamp when engine picks message up
- Calculates time-in-queue (latency)
- Aggregates P50, P95, P99 latency per engine

**Targets (SLA):**
```
ATM-0DTE:     P95 < 30ms  (ultra-fast)
ATG-Intraday: P95 < 50ms  (fast)
AMAT-Prime:   P95 < 75ms  (normal)
ATG-Swing:    P95 < 100ms (acceptable)
AILS:         P95 < 200ms (learning engine, slower OK)
```

**Actions if latency rising:**
1. Alert on P95 crossing threshold
2. Check queue depth (backed up?)
3. Check error rate (failures causing retries?)
4. Possibly trigger rate limiting if sustained high latency

### 4. Error Rate Monitoring
**Objective:** Detect failing engines early

**What it does:**
- Counts failures per engine per hour
- Calculates error rate (failures / total messages)
- Triggers alert if rate exceeds threshold
- Feeds into health score calculation

**Thresholds:**
```yaml
error_rate_threshold: 1%           # Alert if >1% errors
escalation_threshold: 5%           # Critical if >5% errors
circuit_breaker_threshold: 10      # Disable engine after 10 errors in 10 min
```

**Failure types tracked:**
- Message parsing error
- Engine processing timeout
- Alpaca API failure
- Network timeout
- Capital check failure

### 5. Health Scoring (Daily)
**Objective:** One number to understand each engine's fitness

**Daily score (1–10):**
```
Score Calculation:
  Latency Score     = 10 if P95 < target, scale down to 1 if P95 > 3x target
  Availability      = 10 if <0.5% errors, scale down to 1 if >5% errors
  Queue Efficiency  = 10 if depth always <50% threshold, lower if spikes
  Capital Util      = 10 if 20–40% of engine budget deployed, lower if <5% or >60%
  Message Age       = 10 if oldest msg <10s, lower if stuck >30s

Daily Score = AVERAGE(Latency, Availability, Queue, Capital, Age)

Example:
  Latency: 8/10 (P95 = 45ms vs 100ms target)
  Availability: 9/10 (0.3% error rate)
  Queue: 9/10 (depth stable at 30 msgs)
  Capital: 7/10 (only 12% deployed, below target)
  Message Age: 10/10 (oldest msg = 2.1s)
  → Daily Score = 8.6/10 = HEALTHY
```

**Display:**
- 9–10: 🟢 Excellent
- 7–8: 🟡 Good
- 5–6: 🟠 Fair (needs monitoring)
- 3–4: 🔴 Poor (intervention needed)
- 1–2: 🛑 Critical (disable?)

### 6. Circuit Breaker Pattern
**Objective:** Automatically degrade gracefully, not cascade failures

**States:**

```
CLOSED (healthy)
  ↓
  [Engine fails 5 times in 60 seconds]
  ↓
OPEN (disabled)
  - Stop sending new messages
  - Wait 60 seconds
  ↓
HALF_OPEN (recovery test)
  - Send 1 test message
  - If succeeds → back to CLOSED
  - If fails → back to OPEN, reset 60s timer
  ↓
CLOSED (healthy again)
```

**Actions per state:**
```yaml
CLOSED:
  accept_new_messages: true
  route_new_messages: true
  retry_failed: true

OPEN:
  accept_new_messages: false
  route_new_messages: false
  retry_failed: false
  alert: "Engine {name} DISABLED"
  escalate_to: ["cipher", "omni"]

HALF_OPEN:
  accept_new_messages: false
  route_new_messages: false
  test_message: send_one
  on_success: CLOSED
  on_failure: OPEN
```

**Manual override:** Operator can manually open/close via API

### 7. Rate Limiting & Backpressure
**Objective:** Sync OMNI synthesis rate with engine capacity

**How it works:**

```
Every 60 seconds:
  OMNI requests: "can I synthesize 100 picks/min?"
  
  Primus checks engine capacities:
    ATM-0DTE: 85% full, can handle 15/min
    ATG-Swing: 30% full, can handle 70/min
    AMAT-Prime: 50% full, can handle 50/min
    [+ 6 others...]
    Total available: 180/min
  
  OMNI is asking for 100/min
  Primus responds: "OK, proceed at 100/min"
  
  Later, if ATG-Swing queue jumps to 95% full:
    New capacity estimate: 150/min
    Primus sends OMNI: "reduce to 80/min for 5 min"
    OMNI throttles accordingly
```

**Configuration:**
```yaml
rate_limit_check_interval: 60s
capacity_headroom: 20%  # Keep 20% buffer
queue_threshold_warning: 70%  # Alert when queue >70%
queue_threshold_critical: 90%  # Start backpressure at 90%
```

### 8. Anomaly Detection
**Objective:** Catch problems humans would miss

**Anomalies detected:**

1. **Queue Spike**
   - Current depth > 2x rolling average
   - Alert: "ATG-Intraday queue spiked from 50 to 320 msgs"
   - Action: Check error rate, check engine health

2. **Message Stuck**
   - Message age > 30 seconds in queue
   - Alert: "Engine task stuck in ails-queue for 45s"
   - Action: Check engine logs, possibly disable engine

3. **Sudden Error Rate Jump**
   - Error rate > 5x baseline in last 10 min
   - Alert: "AMAT-Prime error rate jumped from 0.2% to 3.2%"
   - Action: Check Alpaca API, check capital available

4. **Queue Not Draining**
   - Queue depth increasing consistently >5 min
   - Alert: "atm-0dte-queue not draining, depth growing"
   - Action: Check if engine is running, check Alpaca latency

5. **Correlated Failures**
   - Multiple engines failing simultaneously
   - Alert: "5 engines reporting errors concurrently"
   - Action: Check shared dependency (Alpaca, capital router, network)

---

## Scope: What Primus Does vs Doesn't Do

### ✅ Primus IS Responsible For
- Queue depth monitoring
- Message tracking & correlation
- Latency measurement
- Error rate calculation
- Health score generation
- Circuit breaker state management
- Rate limiting suggestions to OMNI
- DLQ visibility & recovery interface
- Alert routing based on severity
- Dashboard display (real-time status)

### ❌ Primus is NOT Responsible For
- **Message processing** (engines do that)
- **Synthesis** (OMNI does that)
- **Pick generation** (Cipher does that)
- **Execution** (Alpaca does that)
- **Capital management** (OMNI & Capital Router do that)
- **Position tracking** (CHRONICLE does that)
- **Trade decisions** (engines & Cipher do that)

---

## Integration Model

### Reads From:
- **SQS**: Queue depth, message attributes, DLQ messages
- **CHRONICLE**: Engine thresholds, configuration, historical health
- **Engines**: Status reports, processing metrics (optional)

### Writes To:
- **SQS**: Primus health response messages, rate limit signals
- **CHRONICLE**: Message tracking, health scores, anomaly events
- **Telegram/Alert**: Critical alerts to Ahmed, OMNI, Cipher

### Communicates With:
- **OMNI**: "Your rate limit is X/min" + "Slow down" / "Speed up"
- **Cipher**: "Pick X failed at stage Y because Z"
- **Axiom**: Health dashboard access, anomaly review
- **Operators**: Manual intervention API, dashboard

---

## Key Metrics (Primus Dashboard)

**Top of Page (System Health):**
```
Overall Health: 7.8/10  |  Engines: 7 GREEN, 2 YELLOW  |  Uptime: 99.97%
Queue Status: 485 msgs total (60% of capacity)
Last 10 sec: 47 msgs processed, 3 failed (6.4% error rate)
Rate limit: 280 picks/min (80% of capacity)
```

**Per-Engine Gauge:**
```
ATG-Swing      ████████░ 8.6/10  Queue: 34/200  P95: 42ms  Errors: 0/100
ATG-Intraday   ███████░░ 7.2/10  Queue: 120/500 P95: 68ms  Errors: 2/200
AILS           ██████░░░ 6.1/10  Queue: 180/500 P95: 186ms Errors: 5/80
ATM-MultiWeek  ████████░ 8.1/10  Queue: 15/300  P95: 58ms  Errors: 0/50
ATM-0DTE       ███████░░ 7.9/10  Queue: 240/2000 P95: 28ms Errors: 1/300
AMAT-Prime     █████░░░░ 5.3/10  Queue: 450/1500 P95: 234ms Errors: 18/150 ⚠️
[+ 3 more]
```

**Circuit Breaker Status:**
```
All engines CLOSED (healthy)
AMAT-Prime in DEGRADED mode (warning state)
No engines OPEN
```

**Rate Limit Feedback:**
```
OMNI Requested: 300 picks/min
Primus Allocated: 250 picks/min (ATG-Intraday backing up)
Recommendation: Slow to 220 picks/min for 10 minutes
```

**Recent Anomalies (last 1 hour):**
```
14:52 ⚠️  AMAT-Prime queue spike from 120 → 450 msgs
14:58 🔴 AMAT-Prime error rate: 0.2% → 3.2% (13 errors in 10 min)
15:04 🟡 AILS message stuck for 38s in queue
```

---

## Operational Philosophy

**Primus operates under these principles:**

1. **Visibility First** — Never surprise the operator; show everything happening
2. **Automatic Recovery** — Circuit breakers auto-disable failing engines
3. **Graceful Degradation** — Reduce capacity, don't halt completely
4. **Feedback Loop** — Tell OMNI/Cipher what you learned so they can adapt
5. **Audit Trail** — Log everything so issues can be traced later
6. **Escalation Ladder** — Warn first, alert second, disable third
7. **Human in the Loop** — Provide manual overrides for edge cases

---

## Success Criteria for v1.0

✅ **Implemented & Tested:**
- Real-time queue monitoring (all 9 engines visible)
- End-to-end message tracking (Pick → Order correlation)
- Daily health scoring (1–10 per engine)
- Circuit breaker pattern (auto-disable on failure)
- Rate limiting feedback to OMNI
- Anomaly detection (queue spikes, stuck messages, error jumps)
- DLQ visibility & recovery procedures
- Operational dashboard (real-time status + alerts)
- Runbooks for common issues
- Integration with CHRONICLE + Telegram alerts

✅ **Verified:**
- Dashboard latency <100ms for 9 engines
- Message tracking accuracy >99.9%
- Circuit breaker response <10 seconds
- Health score correlation with manual assessment >0.95

---

## Future Enhancements (Post v1.0)

- [ ] Predictive queue depth (forecast if we'll overflow)
- [ ] Machine learning on error patterns (predict failures)
- [ ] Automatic DLQ replay scheduling
- [ ] Multi-region failover (standby Primus instance)
- [ ] Kubernetes auto-scaling based on queue depth
- [ ] Per-symbol traffic patterns (which symbols clogging which engines?)

---

**Document Version:** 1.0  
**Created:** 2026-06-02  
**Owner:** Maximus  
**Status:** Ready for Implementation
