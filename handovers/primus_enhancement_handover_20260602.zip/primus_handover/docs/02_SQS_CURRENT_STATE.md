# SQS Current State Analysis

**Last Updated:** 2026-06-02  
**Data Source:** Nexus architecture scan + .env configuration  

---

## Current Queue Architecture

### Primary Engine Queues (9 subengines)

| Engine | Queue Name | Purpose | Capacity | SLA |
|--------|-----------|---------|----------|-----|
| **ATG-Swing** | `atg-swing-queue` | Swing trading opportunities (2–5 day holds) | 1000 msgs/min | <100ms |
| **ATG-Intraday** | `atg-intraday-queue` | Intraday momentum (hold <1 day) | 2000 msgs/min | <50ms |
| **AILS** | `ails-queue` | AI-learned signal synthesis | 500 msgs/min | <200ms |
| **ATM-MultiWeek** | `atm-multiweek-queue` | Multi-week thesis trades | 300 msgs/min | <150ms |
| **ATM-0DTE** | `atm-0dte-queue` | 0DTE (day-of-expiration) options | 3000 msgs/min | <30ms |
| **AMAT-Prime** | `amat-prime-queue` | Prime execution engine | 1500 msgs/min | <75ms |
| **[Engine 7]** | `engine-7-queue` | [TBD] | TBD | TBD |
| **[Engine 8]** | `engine-8-queue` | [TBD] | TBD | TBD |
| **[Engine 9]** | `engine-9-queue` | [TBD] | TBD | TBD |

**Total Configured Capacity:** ~9,300 msgs/min (155 msgs/sec)

### Upstream Queues

| Queue Name | Source | Destination | Messages/min | Purpose |
|-----------|--------|-------------|--------------|---------|
| `pick-queue` | Cipher | OMNI | 100–200 | Initial picks from analysis |
| `synthesis-requests` | OMNI | Engines | 200–400 | Synthesis results ready for execution |

### Dead-Letter Queues (DLQs)

Currently **NOT explicitly configured**. Messages that fail processing need to go to DLQs but:
- [ ] No DLQ definitions in IaC
- [ ] No DLQ monitoring setup
- [ ] No DLQ recovery procedures documented
- [ ] Manual checks required to discover failed messages

**Action:** Create 9 DLQs (one per engine) immediately in v1.0

### Message Types & Flow

#### 1. Pick Message (Cipher → pick-queue)
```json
{
  "id": "CIPHER_20260602_001234",
  "timestamp": "2026-06-02T14:30:00Z",
  "symbol": "NVDA",
  "direction": "long",
  "confidence": 0.87,
  "targets": ["120", "125"],
  "stops": ["115"],
  "capital_allocation": 10000
}
```

#### 2. Synthesis Request (pick-queue → synthesis-requests)
```json
{
  "id": "SYNTH_20260602_001234",
  "pick_id": "CIPHER_20260602_001234",
  "symbol": "NVDA",
  "direction": "long",
  "capital_available": 10000,
  "engines_capable": ["ATM-0DTE", "ATG-Intraday", "AMAT-Prime"],
  "expiry_preference": "0DTE",
  "risk_tolerance": "medium"
}
```

#### 3. Engine Task (synthesis-requests → engine queues)
```json
{
  "id": "ENGINE_ATM0DTE_20260602_001234",
  "synth_id": "SYNTH_20260602_001234",
  "engine": "ATM-0DTE",
  "symbol": "NVDA",
  "direction": "long",
  "contracts": [
    {
      "symbol": "NVDA260606C00120000",
      "qty": 10,
      "type": "CALL",
      "price_target": 1.50,
      "stop_loss": 0.50
    }
  ],
  "capital_reserved": 10000
}
```

#### 4. Execution Order (engine → Alpaca)
```json
{
  "id": "ALPACA_20260602_001234",
  "engine_id": "ENGINE_ATM0DTE_20260602_001234",
  "symbol": "NVDA260606C00120000",
  "qty": 10,
  "side": "buy",
  "order_type": "limit",
  "limit_price": 1.50,
  "time_in_force": "day"
}
```

---

## Current Problems & Gaps

### 1. **No End-to-End Tracking**
- A pick enters at `pick-queue`
- No way to know if it made it to Alpaca or where it stopped
- If AILS synthesizes slowly, we don't know which synthesis request failed
- If ATM-0DTE times out, we don't know which engine task never completed

### 2. **No Queue Monitoring**
- Current queue depth unknown
- Latency per engine unknown
- Error rates per engine unknown
- Manual checks required: "aws sqs get-queue-attributes"

### 3. **No Health Scoring**
- Can't tell which engines are healthy vs degraded
- Can't prioritize picks toward healthy engines
- Can't tell OMNI to slow down when engines are backed up

### 4. **No Circuit Breakers**
- If ATG-Intraday fails 10 times, we keep sending it picks
- Can't disable a failing engine automatically
- Cascading failures possible

### 5. **No DLQ Visibility**
- Failed messages disappear into DLQ
- No monitoring of DLQ depth
- Manual recovery procedures non-existent
- Lost message counts unknown

### 6. **No Rate Limiting Between Layers**
- OMNI produces picks at max rate
- Engines sometimes can't keep up
- Queue backing up happens before we notice
- No feedback loop to slow down synthesis

### 7. **No Anomaly Detection**
- Queue spike from 50 msgs to 500 msgs → not detected
- Message stuck in queue >30s → not detected
- Sudden error rate jump → not detected

---

## AWS SQS Configuration Details

### Existing Queue Settings (estimated)

```yaml
VisibilityTimeout: 300 seconds        # Messages invisible for 5 min after pickup
MessageRetentionPeriod: 345600        # 4 days (SQS max is 14 days)
ReceiveMessageWaitTimeSeconds: 20     # Long polling (20s max)
DelaySeconds: 0                       # No delivery delay
MaximumMessageSize: 262144            # 256 KB (SQS standard)
KmsDataKeyReusePeriodSeconds: 300     # Encryption key rotation
```

### Recommended Changes for v1.0

```yaml
VisibilityTimeout: 60 seconds         # Reduce to 60s (faster requeue)
MessageRetentionPeriod: 86400         # Increase to 1 day (better recovery)
ReceiveMessageWaitTimeSeconds: 20     # Keep long polling
DelaySeconds: 0                       # Keep no delay
MaximumMessageSize: 262144            # Keep 256 KB
DLQ Settings:
  MaxReceiveCount: 3                  # Move to DLQ after 3 failures
  DLQ Retention: 86400                # Keep failed messages 1 day
```

---

## Current Throughput Baseline

### Estimated Daily Volume

| Stage | Peak /min | Avg /min | Peak /day | Avg /day |
|-------|-----------|----------|-----------|----------|
| Cipher Picks | 10 | 2 | 14,400 | 2,880 |
| OMNI Syntheses | 20 | 5 | 28,800 | 7,200 |
| Engine Tasks | 300 | 100 | 432,000 | 144,000 |
| Alpaca Orders | 250 | 80 | 360,000 | 115,200 |

### Current Latency Baseline (estimated)

| Stage | P50 | P95 | P99 | SLA |
|-------|-----|-----|-----|-----|
| Pick → Synthesis | 50ms | 200ms | 500ms | <1s |
| Synthesis → Engine | 100ms | 500ms | 2s | <2s |
| Engine → Alpaca | 75ms | 300ms | 1s | <1.5s |
| Total Pick → Order | 225ms | 1s | 3.5s | <5s |

---

## Infrastructure Dependencies

### SQS-Related Services

```
AWS SQS (cloud)
├── IAM Role: nexus-sqs-access
├── KMS Key: nexus-sqs-encryption
└── CloudWatch Metrics: SQS Namespace

Message Broker (RabbitMQ, local)
├── Host: 192.168.1.141:5672
├── User: nexus
└── Vhost: /nexus

Python SQS Client (boto3)
├── Package: boto3 ~= 1.28.0
├── Region: us-east-1
└── Endpoint: https://sqs.us-east-1.amazonaws.com

CHRONICLE Database
├── Table: sqs_messages (current)
├── Table: sqs_tracking (needs creation)
└── Table: sqs_health (needs creation)
```

---

## Known Issues & Workarounds

### Issue 1: Queue Lag During Market Open
**Symptom:** Queue depth spikes from 50 to 500 msgs in first 30 min of market
**Cause:** All engines fire at market open simultaneously
**Current Workaround:** Manual throttling by reducing Cipher pick rate
**v1.0 Solution:** Automated rate limiting via Primus

### Issue 2: Hung Messages
**Symptom:** Message stays in queue >60s without processing
**Cause:** Engine crashes mid-processing, message visibility timeout expires
**Current Workaround:** Manual queue purge or visibility reset
**v1.0 Solution:** Automatic anomaly detection + DLQ requeue

### Issue 3: DLQ Overflow
**Symptom:** Failed messages accumulate invisibly
**Cause:** No DLQ monitoring; failed messages not retried
**Current Workaround:** Manual check and re-injection
**v1.0 Solution:** DLQ monitoring dashboard + one-click recovery

### Issue 4: No Engine Prioritization
**Symptom:** All engines get same incoming pick rate regardless of health
**Cause:** No health feedback loop
**Current Workaround:** Manual engine disabling when degraded
**v1.0 Solution:** Automatic health scoring + routing adjustment

---

## Proposed SQS Changes for v1.0

### New Queues to Create

```yaml
# Dead-Letter Queues (one per engine)
- atg-swing-dlq
- atg-intraday-dlq
- ails-dlq
- atm-multiweek-dlq
- atm-0dte-dlq
- amat-prime-dlq
- engine-7-dlq
- engine-8-dlq
- engine-9-dlq

# Primus control/response queues
- primus-health-responses       # Health check ACKs
- primus-circuit-breaker-events # CB state changes
- primus-rate-limit-updates     # OMNI rate limit signals

# Optional (for future scaling)
- primus-replay-queue           # Failed message replay
- primus-metrics-queue          # Health metrics streaming
```

### Queue Configuration Changes

```yaml
all_engine_queues:
  MessageRetentionPeriod: 86400         # 1 day (increase from current)
  VisibilityTimeout: 60                 # Reduce from 300 for faster requeue
  RedrivePolicy:                        # Add DLQ binding
    deadLetterTargetArn: "arn:..."
    maxReceiveCount: 3
  ReceiveMessageWaitTimeSeconds: 20     # Keep long polling
```

---

## Monitoring Baseline (Current)

**Current Monitoring:** Manual checks only
```bash
# Check queue depth manually
aws sqs get-queue-attributes \
  --queue-url https://sqs.us-east-1.amazonaws.com/.../atg-swing-queue \
  --attribute-names ApproximateNumberOfMessages

# Check DLQ (if exists)
# [No DLQ configured currently]
```

**Gaps:**
- No automated polling of queue depth
- No latency tracking per message
- No error rate calculation
- No alerting on queue anomalies
- No health dashboard

---

## Next Steps for Primus v1.0

1. **Create DLQs** — 9 new dead-letter queues immediately
2. **Add SQS monitoring** — CloudWatch metrics subscription
3. **Build tracking layer** — Primus reads message IDs, timestamps
4. **Implement health scoring** — Daily engine health 1–10 calculation
5. **Deploy dashboard** — Real-time monitoring UI
6. **Integrate rate limiting** — OMNI feedback loop
7. **Add circuit breakers** — Auto-disable failed engines
8. **Document runbooks** — Queue diagnostics, DLQ recovery

---

## Appendix: Queue URL Reference

```
Pick Queue:
  https://sqs.us-east-1.amazonaws.com/{account-id}/pick-queue

Synthesis Queue:
  https://sqs.us-east-1.amazonaws.com/{account-id}/synthesis-requests

Engine Queues:
  https://sqs.us-east-1.amazonaws.com/{account-id}/atg-swing-queue
  https://sqs.us-east-1.amazonaws.com/{account-id}/atg-intraday-queue
  https://sqs.us-east-1.amazonaws.com/{account-id}/ails-queue
  https://sqs.us-east-1.amazonaws.com/{account-id}/atm-multiweek-queue
  https://sqs.us-east-1.amazonaws.com/{account-id}/atm-0dte-queue
  https://sqs.us-east-1.amazonaws.com/{account-id}/amat-prime-queue
  [+ 3 more]

Dead-Letter Queues (to be created):
  https://sqs.us-east-1.amazonaws.com/{account-id}/atg-swing-dlq
  [+ 8 more, one per engine]
```

---

**Document Version:** 1.0  
**Created:** 2026-06-02  
**Review Status:** Ready for Architecture Review
