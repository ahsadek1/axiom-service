# EXECUTIVE SUMMARY: Primus v1.0 — Central SQS Orchestrator

**Status:** Design Phase Ready for Implementation  
**Owner:** Maximus (Implementation Lead)  
**Stakeholders:** Cipher (Architecture), OMNI (Synthesis), Atlas (Picks), Axiom (Oversight)

---

## The Problem We're Solving

**Current State:**
- 9 independent trading engines (ATG-Swing, ATG-Intraday, AILS, ATM-MultiWeek, ATM-0DTE, AMAT-Prime, + 3 others)
- Each engine has its own SQS queue, no central visibility
- No end-to-end message tracking (which pick led to which order?)
- No coordinated rate limiting between synthesis (OMNI) and engine capacity
- Manual intervention required when engines stall or queues back up
- DLQ (dead-letter queues) invisible until manually checked
- No health scoring to understand engine-by-engine performance

**Impact:**
- ❌ Can't diagnose why a pick failed to execute
- ❌ Can't predict queue overflow before it happens
- ❌ Can't scale engines intelligently (add capacity where needed)
- ❌ Synthesis (OMNI) doesn't know engine capacity → produces picks engines can't handle
- ❌ Failures cascade (one engine down → doesn't notify execution layer)

---

## Primus Solution

**What is Primus?**

Primus is a **central SQS orchestrator and supervisor** that sits between Cipher's picks, OMNI's synthesis, and the 9 trading engines.

**Its core job:**
1. **Route messages** — Pick → SynthesisRequest → EngineTask → ExecutionOrder
2. **Monitor queues** — Real-time visibility into depth, latency, errors per engine
3. **Score engine health** — Daily 1–10 score based on: latency, error rates, capital utilization, queue depth, message age
4. **Detect anomalies** — Flag sudden queue spikes, hung messages, stalled engines
5. **Enforce circuit breakers** — Auto-disable failed engines, recover gracefully
6. **Rate-limit synthesis** — Tell OMNI "we can only handle X picks/minute right now"
7. **Track end-to-end** — Message ID → engine execution → Alpaca order → position

**Why this matters:**
- Cipher knows instantly which picks failed and why
- OMNI synergizes at the speed engines can handle, not faster
- Atlas optimizes picks based on real engine performance data
- Axiom monitors the entire flow with one pane of glass
- Engineers can diagnose issues in 2 minutes instead of 20

---

## Architecture at a Glance

```
Cipher (Picks)
    ↓
  SQS: pick-queue
    ↓
OMNI (Synthesis)
    ↓
  SQS: synthesis-requests
    ↓
[PRIMUS ORCHESTRATOR]  ← Central Hub
    ↓
  9x SQS Queues (one per engine)
    ↓
ATG-Swing | ATG-Intraday | AILS | ATM-MultiWeek | ATM-0DTE | AMAT-Prime | ...
    ↓
Alpaca (Execute Orders)
    ↓
Positions (CHRONICLE)
```

**Primus monitors & controls at each layer:**
- Incoming pick rate (how fast are Cipher picks coming in?)
- Synthesis rate (how fast is OMNI processing?)
- Queue depths per engine (are any backed up?)
- Message latency (how long in each queue?)
- Error rates (how many messages failed?)
- Capital utilization (what % of capital is deployed per engine?)
- Message age (which messages are stuck oldest?)

---

## Key Capabilities

### 1. **Real-Time Queue Monitoring Dashboard**
- Queue depth per engine (visual gauge: green → yellow → red)
- Latency per engine (pickup → engine execution time)
- Error rate per engine (failures in last hour, 24h)
- Messages in DLQ per engine
- Overall system health score (1–10)

### 2. **End-to-End Message Tracking**
```
Pick ID: CIPHER_20260602_001234
  ↓ SynthesisRequest: SYNTH_20260602_001234
    ↓ EngineTask: ENGINE_ATM0DTE_20260602_001234
      ↓ ExecutionOrder: ALPACA_20260602_001234
        ↓ Position: POS_NVDA_20260602_001234
```

If a pick didn't execute, Primus shows exactly where it stopped.

### 3. **Engine Health Scoring (Daily)**
```
ATG-Swing:
  Latency:           45ms (target: <100ms) ✓
  Error Rate:        0.2% (target: <1%) ✓
  Capital Util:      28% (target: 20–40%) ✓
  Queue Depth:       12 msgs (target: <50) ✓
  Oldest Msg Age:    2.1s (target: <10s) ✓
  DAILY SCORE:       9/10 (Excellent)

AILS:
  Latency:           320ms (target: <100ms) ⚠️
  Error Rate:        3.2% (target: <1%) ⚠️
  Capital Util:      5% (target: 20–40%) ⚠️
  Queue Depth:       240 msgs (target: <50) ⚠️
  Oldest Msg Age:    18.3s (target: <10s) ⚠️
  DAILY SCORE:       3/10 (Needs Attention)
```

### 4. **Automated Circuit Breakers**
- **Normal** → Engine is healthy, accepting tasks
- **Degraded** → Latency rising, error rate increasing → reduce queue submission rate
- **Disabled** → Engine failed >5 times in 10 min → stop sending tasks
- **Recovery** → Engine recovered → gradually re-enable

### 5. **Anomaly Detection**
- Queue depth spike (>2x normal) → alert
- Message stuck >30s in queue → alert
- Error rate spike (>5x baseline) → alert
- Engine not draining queue → alert

### 6. **Rate Limiting & Backpressure**
```
OMNI requests 100 picks/min synthesis
Primus checks engine capacity:
  - ATM-0DTE: can handle 40/min
  - ATG-Swing: can handle 30/min
  - AILS: can handle 15/min (degraded)
  Total capacity: 85/min

Primus tells OMNI: "reduce to 80 picks/min for next 5 minutes"
OMNI throttles accordingly
```

---

## Integration Points

### With OMNI (Synthesis)
- **Input:** Synthesis requests at variable rate
- **Feedback:** Queue capacity metrics every 10s
- **Control:** Rate limit (can tell OMNI to slow down)
- **Escalation:** Critical threshold (engine down) → alert OMNI to pause synthesis

### With Cipher (Pick Generation)
- **Input:** New picks
- **Feedback:** Pick-to-execution tracking
- **Escalation:** Pick failed end-to-end → alert Cipher with reason

### With Alpaca (Execution)
- **Input:** Execution results, fill notifications
- **Feedback:** Order success/failure, fill prices
- **Escalation:** Repeated execution failures → disable engine

### With CHRONICLE (Audit Log)
- **Input:** Read operational parameters, thresholds
- **Output:** Log every message ID, engine assignment, tracking data
- **Read:** Health scores, monitoring snapshots daily

### With Axiom (Oversight)
- **Input:** Daily health scores, anomaly reports
- **Escalation:** Critical issues → Telegram to Ahmed
- **Dashboards:** Real-time monitoring for oversight

---

## Implementation Phases

### Phase 1: Core Infrastructure (Week 1)
- [ ] Create SQS monitoring tables in CHRONICLE
- [ ] Build message ID generation & tracking system
- [ ] Implement basic queue depth monitoring

### Phase 2: Health & Scoring (Week 2)
- [ ] Implement latency tracking per engine
- [ ] Build health scoring algorithm
- [ ] Create daily score calculation & storage

### Phase 3: Circuit Breakers (Week 2–3)
- [ ] Implement circuit breaker state machine
- [ ] Wire into message routing (respect CB state)
- [ ] Test failover scenarios

### Phase 4: Dashboard & Ops (Week 3)
- [ ] Build real-time monitoring dashboard
- [ ] Implement anomaly detection
- [ ] Create runbooks for operators

### Phase 5: Integration & Tuning (Week 4)
- [ ] Integrate with OMNI for rate limiting
- [ ] Integrate with Cipher for tracking
- [ ] Load test under full production patterns

---

## Success Metrics for v1.0

| Metric | Target | Verification |
|--------|--------|--------------|
| Queue visibility latency | <100ms | Dashboard shows real-time depth |
| Message tracking accuracy | 99.9% | Sample 1000 picks, track to Alpaca |
| Circuit breaker response time | <10s | Fail engine, measure disable time |
| Health score correlation | >0.95 | Compare score with human assessment |
| DLQ recovery time | <2 min | Manual procedure from DLQ notification |
| Rate limiting responsiveness | <30s | Change OMNI rate, measure engine response |

---

## Risks & Mitigation

| Risk | Impact | Mitigation |
|------|--------|-----------|
| Queue lag during peak load | Picks execute slow | Rate limiting, auto-scaling |
| Message loss on Primus crash | Orphaned picks | CHRONICLE audit trail, recovery scan |
| Circuit breaker too aggressive | Good engines disabled | Threshold tuning, manual override |
| Dashboard performance at scale | Operators can't respond | Streaming updates, aggregation, caching |
| Integration complexity with OMNI | Delays synthesis | Clean API contract, early testing |

---

## Deliverables in This Package

1. **Architecture Specification** (`docs/04_ARCHITECTURE.md`)
2. **SQS Current State Analysis** (`docs/02_SQS_CURRENT_STATE.md`)
3. **Oversight Requirements** (`docs/05_OVERSIGHT_REQUIREMENTS.md`)
4. **Integration Points** (`docs/06_INTEGRATION_POINTS.md`)
5. **Database Schemas** (`schemas/*.sql`)
6. **Skeleton Code** (`code/*.py`)
7. **Deployment Runbooks** (`runbooks/*.md`)
8. **Configuration Templates** (`config/`)

---

## Timeline & Ownership

| Phase | Timeline | Owner | Approver |
|-------|----------|-------|----------|
| Design Review | 2 days | Maximus | Cipher |
| Development | 5 days | Maximus | — |
| Integration Testing | 3 days | Maximus + OMNI | — |
| Staging Deployment | 2 days | Maximus | Cipher |
| Production Rollout | 1 day | Maximus | Ahmed + Cipher |

**Total: 13 days → Primus v1.0 live in production**

---

## Next Steps

1. **Review this summary** with Cipher & OMNI (30 min)
2. **Validate architecture** (`docs/04_ARCHITECTURE.md`) with team (1 hour)
3. **Create JIRA epic** with phases from above
4. **Begin Phase 1** development
5. **Daily sync** with Cipher on integration progress

**Questions?** Reference `docs/06_INTEGRATION_POINTS.md` for data flow, or `runbooks/DEPLOYMENT.md` for operational details.

---

**Document Version:** 1.0  
**Created:** 2026-06-02  
**Status:** Ready for Implementation Review
